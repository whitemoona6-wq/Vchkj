#!/usr/bin/env python3
"""
Grok Steam — простой backend на Flask
Запуск:  python app.py
Открыть: http://127.0.0.1:5000
"""

from flask import Flask, jsonify, request, send_from_directory, session
from flask_cors import CORS
from functools import wraps
import os
import json
import uuid
from datetime import datetime

app = Flask(__name__, static_folder=".", static_url_path="")
app.secret_key = os.environ.get("SECRET_KEY", "grok-steam-dev-secret-change-me")
CORS(app, supports_credentials=True)

# ─── Данные игр (те же, что в data.js) ───────────────────────────────────────

GAMES = [
    {
        "id": 1,
        "title": "Cyberpunk 2077",
        "price": 1999,
        "oldPrice": 3999,
        "discount": 50,
        "category": ["rpg", "action"],
        "tags": ["RPG", "Открытый мир", "Киберпанк"],
        "description": "Cyberpunk 2077 — приключенческая ролевая игра, действие которой происходит в мегаполисе Найт-Сити, где власть, гламур и модификации тела ценятся выше всего. Вы играете за V — наёмника в поисках уникального импланта, позволяющего обрести бессмертие.",
        "cover": "linear-gradient(135deg, #f7971e 0%, #ffd200 50%, #1a1a2e 50%, #16213e 100%)",
        "featured": True,
        "release": "10 дек. 2020",
        "developer": "CD PROJEKT RED",
        "publisher": "CD PROJEKT RED",
        "rating": 4.5,
    },
    {
        "id": 2,
        "title": "Elden Ring",
        "price": 2499,
        "oldPrice": 3999,
        "discount": 38,
        "category": ["rpg", "action"],
        "tags": ["Souls-like", "Открытый мир", "Фэнтези"],
        "description": "ВОССТАНЬ, ПОТУСКНЕВШИЙ. Междуземье ждёт. Новая фэнтезийная ролевая игра и духовный наследник легендарных Dark Souls, созданный Хидэтакой Миядзаки и Джорджем Р. Р. Мартином.",
        "cover": "linear-gradient(135deg, #2c1810 0%, #8b4513 40%, #1a0a00 100%)",
        "featured": False,
        "release": "25 фев. 2022",
        "developer": "FromSoftware",
        "publisher": "Bandai Namco",
        "rating": 4.8,
    },
    {
        "id": 3,
        "title": "Stardew Valley",
        "price": 499,
        "oldPrice": None,
        "discount": 0,
        "category": ["simulation", "indie"],
        "tags": ["Симулятор", "Ферма", "Инди"],
        "description": "Вы унаследовали старую ферму деда в Stardew Valley. Вооружившись инструментами и решимостью, вы начинаете новую жизнь.",
        "cover": "linear-gradient(135deg, #56ab2f 0%, #a8e063 50%, #2d5016 100%)",
        "featured": False,
        "release": "26 фев. 2016",
        "developer": "ConcernedApe",
        "publisher": "ConcernedApe",
        "rating": 4.9,
    },
    {
        "id": 4,
        "title": "Counter-Strike 2",
        "price": 0,
        "oldPrice": None,
        "discount": 0,
        "category": ["action"],
        "tags": ["Шутер", "Мультиплеер", "Бесплатно"],
        "description": "Более 20 лет Counter-Strike остаётся одним из самых популярных шутеров в мире. Теперь серия переходит на Source 2.",
        "cover": "linear-gradient(135deg, #1a1a2e 0%, #e94560 40%, #0f0f1a 100%)",
        "featured": False,
        "release": "27 сен. 2023",
        "developer": "Valve",
        "publisher": "Valve",
        "rating": 4.3,
    },
    {
        "id": 5,
        "title": "Hades II",
        "price": 1499,
        "oldPrice": 1999,
        "discount": 25,
        "category": ["action", "indie", "rpg"],
        "tags": ["Roguelike", "Инди", "Мифология"],
        "description": "Битва за Олимп продолжается в Hades II — долгожданном сиквеле отмеченного наградами roguelike от Supergiant Games.",
        "cover": "linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)",
        "featured": True,
        "release": "6 мая 2024",
        "developer": "Supergiant Games",
        "publisher": "Supergiant Games",
        "rating": 4.7,
    },
    {
        "id": 6,
        "title": "Baldur's Gate 3",
        "price": 2999,
        "oldPrice": 3999,
        "discount": 25,
        "category": ["rpg"],
        "tags": ["RPG", "Турновая", "Фэнтези"],
        "description": "Соберите отряд и вернитесь в Забытые Королевства в истории о дружбе и предательстве, жертве и выживании.",
        "cover": "linear-gradient(135deg, #1a0000 0%, #8b0000 40%, #2a0a0a 100%)",
        "featured": True,
        "release": "3 авг. 2023",
        "developer": "Larian Studios",
        "publisher": "Larian Studios",
        "rating": 4.9,
    },
    {
        "id": 7,
        "title": "The Witcher 3: Wild Hunt",
        "price": 599,
        "oldPrice": 1999,
        "discount": 70,
        "category": ["rpg", "action", "adventure"],
        "tags": ["RPG", "Открытый мир", "Фэнтези"],
        "description": "Вы — Геральт из Ривии, охотник на монстров. В мире, охваченном войной, вы преследуете дитя пророчества — Цири.",
        "cover": "linear-gradient(135deg, #0a1628 0%, #1e3a5f 40%, #0d2137 100%)",
        "featured": False,
        "release": "19 мая 2015",
        "developer": "CD PROJEKT RED",
        "publisher": "CD PROJEKT RED",
        "rating": 4.8,
    },
    {
        "id": 8,
        "title": "Terraria",
        "price": 399,
        "oldPrice": None,
        "discount": 0,
        "category": ["adventure", "indie"],
        "tags": ["Песочница", "Крафт", "2D"],
        "description": "Копайте, сражайтесь, исследуйте, стройте! Нет ничего невозможного в этой насыщенной событиями приключенческой игре.",
        "cover": "linear-gradient(135deg, #1a472a 0%, #2d6a4f 50%, #081c15 100%)",
        "featured": False,
        "release": "16 мая 2011",
        "developer": "Re-Logic",
        "publisher": "Re-Logic",
        "rating": 4.8,
    },
    {
        "id": 9,
        "title": "Civilization VI",
        "price": 899,
        "oldPrice": 2999,
        "discount": 70,
        "category": ["strategy"],
        "tags": ["Стратегия", "Пошаговая", "История"],
        "description": "Создайте империю, которая выдержит испытание временем в Civilization VI.",
        "cover": "linear-gradient(135deg, #1a3a5c 0%, #4a90d9 40%, #0d1b2a 100%)",
        "featured": False,
        "release": "21 окт. 2016",
        "developer": "Firaxis Games",
        "publisher": "2K",
        "rating": 4.6,
    },
    {
        "id": 10,
        "title": "Hollow Knight",
        "price": 499,
        "oldPrice": None,
        "discount": 0,
        "category": ["adventure", "indie", "action"],
        "tags": ["Metroidvania", "Инди", "2D"],
        "description": "Исследуйте огромное разрушенное королевство насекомых и героев.",
        "cover": "linear-gradient(135deg, #0d0d1a 0%, #2a2a4a 40%, #1a1a2e 100%)",
        "featured": False,
        "release": "24 фев. 2017",
        "developer": "Team Cherry",
        "publisher": "Team Cherry",
        "rating": 4.9,
    },
    {
        "id": 11,
        "title": "Red Dead Redemption 2",
        "price": 1499,
        "oldPrice": 3999,
        "discount": 63,
        "category": ["action", "adventure"],
        "tags": ["Открытый мир", "Вестерн", "Сюжет"],
        "description": "Америка, 1899 год. Артур Морган и банда Ван дер Линде вынуждены бежать.",
        "cover": "linear-gradient(135deg, #2c1810 0%, #5c3317 40%, #1a0f0a 100%)",
        "featured": False,
        "release": "5 дек. 2019",
        "developer": "Rockstar Games",
        "publisher": "Rockstar Games",
        "rating": 4.7,
    },
    {
        "id": 12,
        "title": "Factorio",
        "price": 1299,
        "oldPrice": None,
        "discount": 0,
        "category": ["strategy", "simulation", "indie"],
        "tags": ["Автоматизация", "Стратегия", "Инди"],
        "description": "Factorio — игра об автоматизации. Вы разбились на чужой планете и должны добывать ресурсы, исследовать технологии, строить фабрики.",
        "cover": "linear-gradient(135deg, #3d2914 0%, #8b6914 40%, #1a1208 100%)",
        "featured": False,
        "release": "14 авг. 2020",
        "developer": "Wube Software",
        "publisher": "Wube Software",
        "rating": 4.9,
    },
    {
        "id": 13,
        "title": "Portal 2",
        "price": 299,
        "oldPrice": 999,
        "discount": 70,
        "category": ["adventure", "action"],
        "tags": ["Головоломка", "Научная фантастика", "Кооп"],
        "description": "Одиночная и кооперативная кампания Portal 2 расширяют вселенную оригинальной игры.",
        "cover": "linear-gradient(135deg, #1a3a5c 0%, #ff6b35 40%, #0d1b2a 100%)",
        "featured": False,
        "release": "19 апр. 2011",
        "developer": "Valve",
        "publisher": "Valve",
        "rating": 4.9,
    },
    {
        "id": 14,
        "title": "Among Us",
        "price": 0,
        "oldPrice": None,
        "discount": 0,
        "category": ["indie", "action"],
        "tags": ["Мультиплеер", "Социальная", "Бесплатно"],
        "description": "Играйте с 4–15 игроками онлайн или по локальной сети, пока выполняете задания на космическом корабле.",
        "cover": "linear-gradient(135deg, #1a1a2e 0%, #e94560 30%, #0f3460 100%)",
        "featured": False,
        "release": "15 июн. 2018",
        "developer": "Innersloth",
        "publisher": "Innersloth",
        "rating": 4.2,
    },
    {
        "id": 15,
        "title": "Disco Elysium",
        "price": 799,
        "oldPrice": 1599,
        "discount": 50,
        "category": ["rpg", "adventure", "indie"],
        "tags": ["RPG", "Детектив", "Нарратив"],
        "description": "Disco Elysium — новаторская ролевая игра с открытым миром. Вы — детектив с уникальной системой навыков.",
        "cover": "linear-gradient(135deg, #2a1a3a 0%, #6b3a8a 40%, #1a0a2a 100%)",
        "featured": False,
        "release": "15 окт. 2019",
        "developer": "ZA/UM",
        "publisher": "ZA/UM",
        "rating": 4.8,
    },
    {
        "id": 16,
        "title": "Cities: Skylines II",
        "price": 2499,
        "oldPrice": None,
        "discount": 0,
        "category": ["simulation", "strategy"],
        "tags": ["Симулятор", "Градостроительство", "Стратегия"],
        "description": "Стройте город своей мечты. Cities: Skylines II — самая реалистичная симуляция города.",
        "cover": "linear-gradient(135deg, #0a2a4a 0%, #1a6a9a 40%, #051525 100%)",
        "featured": False,
        "release": "24 окт. 2023",
        "developer": "Colossal Order",
        "publisher": "Paradox Interactive",
        "rating": 4.0,
    },
]

# In-memory storage (для демо; в проде — БД)
USERS: dict = {}          # email -> {password, name, library: [ids], cart: [ids]}
ORDERS: list = []


def get_game(game_id: int):
    return next((g for g in GAMES if g["id"] == game_id), None)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_email" not in session:
            return jsonify({"error": "Требуется авторизация"}), 401
        return f(*args, **kwargs)
    return decorated


# ─── Статика ────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(".", path)


# ─── API: Игры ──────────────────────────────────────────────────────────────

@app.route("/api/games")
def api_games():
    """Список игр с фильтрами: ?category=rpg&q=witcher&discount=1"""
    category = request.args.get("category", "all")
    q = request.args.get("q", "").strip().lower()
    only_discount = request.args.get("discount") == "1"

    result = GAMES
    if category and category != "all":
        result = [g for g in result if category in g["category"]]
    if q:
        result = [
            g for g in result
            if q in g["title"].lower() or any(q in t.lower() for t in g["tags"])
        ]
    if only_discount:
        result = [g for g in result if g["discount"] > 0]

    return jsonify(result)


@app.route("/api/games/<int:game_id>")
def api_game(game_id):
    game = get_game(game_id)
    if not game:
        return jsonify({"error": "Игра не найдена"}), 404
    return jsonify(game)


@app.route("/api/games/featured")
def api_featured():
    featured = [g for g in GAMES if g.get("featured")]
    return jsonify(featured or GAMES[:3])


# ─── API: Авторизация ───────────────────────────────────────────────────────

@app.route("/api/auth/register", methods=["POST"])
def api_register():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    name = (data.get("name") or "").strip()

    if not email or not password or len(password) < 6:
        return jsonify({"error": "Укажите email и пароль (мин. 6 символов)"}), 400
    if not name:
        return jsonify({"error": "Укажите имя"}), 400
    if email in USERS:
        return jsonify({"error": "Пользователь уже существует"}), 409

    USERS[email] = {
        "password": password,  # в проде — хеш!
        "name": name,
        "library": [],
        "cart": [],
        "created_at": datetime.utcnow().isoformat(),
    }
    session["user_email"] = email
    return jsonify({"email": email, "name": name}), 201


@app.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = USERS.get(email)
    if not user or user["password"] != password:
        return jsonify({"error": "Неверный email или пароль"}), 401

    session["user_email"] = email
    return jsonify({"email": email, "name": user["name"]})


@app.route("/api/auth/logout", methods=["POST"])
def api_logout():
    session.pop("user_email", None)
    return jsonify({"ok": True})


@app.route("/api/auth/me")
def api_me():
    email = session.get("user_email")
    if not email or email not in USERS:
        return jsonify({"user": None})
    user = USERS[email]
    return jsonify({
        "user": {
            "email": email,
            "name": user["name"],
            "library": user["library"],
            "cart": user["cart"],
        }
    })


# ─── API: Корзина ───────────────────────────────────────────────────────────

@app.route("/api/cart")
@login_required
def api_cart():
    email = session["user_email"]
    cart_ids = USERS[email]["cart"]
    items = [get_game(i) for i in cart_ids if get_game(i)]
    total = sum(g["price"] for g in items)
    return jsonify({"items": items, "total": total, "count": len(items)})


@app.route("/api/cart/add", methods=["POST"])
@login_required
def api_cart_add():
    data = request.get_json(silent=True) or {}
    game_id = data.get("game_id")
    if not game_id or not get_game(game_id):
        return jsonify({"error": "Игра не найдена"}), 404

    user = USERS[session["user_email"]]
    if game_id in user["library"]:
        return jsonify({"error": "Игра уже в библиотеке"}), 400
    if game_id in user["cart"]:
        return jsonify({"error": "Игра уже в корзине"}), 400

    user["cart"].append(game_id)
    return jsonify({"ok": True, "cart": user["cart"]})


@app.route("/api/cart/remove", methods=["POST"])
@login_required
def api_cart_remove():
    data = request.get_json(silent=True) or {}
    game_id = data.get("game_id")
    user = USERS[session["user_email"]]
    if game_id in user["cart"]:
        user["cart"].remove(game_id)
    return jsonify({"ok": True, "cart": user["cart"]})


@app.route("/api/cart/clear", methods=["POST"])
@login_required
def api_cart_clear():
    USERS[session["user_email"]]["cart"] = []
    return jsonify({"ok": True})


# ─── API: Покупка / Библиотека ──────────────────────────────────────────────

@app.route("/api/checkout", methods=["POST"])
@login_required
def api_checkout():
    email = session["user_email"]
    user = USERS[email]
    if not user["cart"]:
        return jsonify({"error": "Корзина пуста"}), 400

    order_id = str(uuid.uuid4())[:8]
    items = [get_game(i) for i in user["cart"] if get_game(i)]
    total = sum(g["price"] for g in items)

    # Добавляем в библиотеку
    for gid in user["cart"]:
        if gid not in user["library"]:
            user["library"].append(gid)
    user["cart"] = []

    order = {
        "id": order_id,
        "email": email,
        "items": [g["id"] for g in items],
        "total": total,
        "created_at": datetime.utcnow().isoformat(),
    }
    ORDERS.append(order)

    return jsonify({
        "ok": True,
        "order_id": order_id,
        "total": total,
        "library": user["library"],
        "message": "Покупка успешно оформлена!",
    })


@app.route("/api/library")
@login_required
def api_library():
    email = session["user_email"]
    lib_ids = USERS[email]["library"]
    games = [get_game(i) for i in lib_ids if get_game(i)]
    return jsonify({"games": games, "count": len(games)})


# ─── Health ─────────────────────────────────────────────────────────────────

@app.route("/api/health")
def api_health():
    return jsonify({
        "status": "ok",
        "games": len(GAMES),
        "users": len(USERS),
        "orders": len(ORDERS),
    })


# ─── Запуск ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 50)
    print("  Grok Steam — http://127.0.0.1:5000")
    print("  API: /api/games, /api/cart, /api/auth/...")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True)
