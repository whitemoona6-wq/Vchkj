const GAMES = [
  {
    id: 1,
    title: "Cyberpunk 2077",
    price: 1999, oldPrice: 3999, discount: 50,
    category: ["rpg", "action"],
    tags: ["RPG", "Открытый мир", "Киберпанк", "Одиночная"],
    description: "Cyberpunk 2077 — приключенческая ролевая игра от первого лица, действие которой происходит в Найт-Сити, мегаполисе будущего, одержимом властью, гламуром и модификациями тела.\n\nВы играете за V — наёмника в поисках уникального импланта, который является ключом к бессмертию. Создайте своего персонажа, выберите происхождение (Корпорат, Уличный панк или Кочевник) и исследуйте огромный открытый мир.\n\nСражайтесь с помощью огнестрельного оружия, холодного оружия и кибернетических способностей. Выполняйте заказы, погружайтесь в интриги корпораций и принимайте решения, которые меняют судьбу города и ваших союзников.\n\nИгра включает масштабное обновление 2.0 и дополнение Phantom Liberty с новой историей, районом и персонажами.",
    shortDesc: "Откройте мир Найт-Сити — мегаполиса одержимости властью, гламуром и модификациями тела.",
    cover: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=640&h=360&fit=crop&q=80"
    ],
    featured: true, release: "10 дек. 2020",
    developer: "CD PROJEKT RED", publisher: "CD PROJEKT RED",
    rating: 4.5, reviews: 12840, platforms: ["Windows", "macOS"],
    ageRating: "18+", languages: ["Русский", "English", "Deutsch", "Français"],
    sysReq: {
      min: "OS: Windows 10 64-bit · CPU: Intel Core i5-3570K / AMD FX-8310 · RAM: 8 GB · GPU: GTX 780 / Radeon RX 470 · Storage: 70 GB",
      rec: "OS: Windows 10 64-bit · CPU: Intel Core i7-4790 / AMD Ryzen 3 3200G · RAM: 12 GB · GPU: GTX 1060 6GB / Radeon RX 590 · Storage: 70 GB SSD"
    }
  },
  {
    id: 2,
    title: "Elden Ring",
    price: 2499, oldPrice: 3999, discount: 38,
    category: ["rpg", "action"],
    tags: ["Souls-like", "Открытый мир", "Фэнтези", "Сложный"],
    description: "ВОССТАНЬ, ПОТУСКНЕВШИЙ.\n\nМеждуземье ждёт. Elden Ring — новая фэнтезийная action-RPG и духовный наследник Dark Souls, созданный Хидэтакой Миядзаки (FromSoftware) в сотрудничестве с Джорджем Р. Р. Мартином.\n\nИсследуйте огромный мир, полный опасностей и тайн. Сражайтесь с колоссальными боссами, собирайте могущественное оружие и заклинания, прокачивайте персонажа под свой стиль.\n\nОткрытый мир позволяет идти своим путём: можно обойти сложных врагов, найти скрытые локации и раскрыть историю Расколотого Кольца в удобном темпе.\n\nПоддержка кооператива и вторжений PvP. Дополнение Shadow of the Erdtree расширяет карту и добавляет десятки часов контента.",
    shortDesc: "Восстань, Потускневший. Междуземье ждёт в духовном наследнике Dark Souls.",
    cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1579373903781-fd5c0d1c7b5b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1614294148960-9aa7406326c0?w=640&h=360&fit=crop&q=80"
    ],
    featured: true, release: "25 фев. 2022",
    developer: "FromSoftware", publisher: "Bandai Namco",
    rating: 4.8, reviews: 24500, platforms: ["Windows"],
    ageRating: "16+", languages: ["Русский", "English", "日本語"],
    sysReq: {
      min: "OS: Windows 10 · CPU: Intel i5-8400 / AMD Ryzen 3 3300X · RAM: 12 GB · GPU: GTX 1060 3GB / RX 580 4GB · Storage: 60 GB",
      rec: "OS: Windows 10/11 · CPU: Intel i7-8700K / AMD Ryzen 5 3600X · RAM: 16 GB · GPU: GTX 1070 / RX Vega 56 · Storage: 60 GB SSD"
    }
  },
  {
    id: 3,
    title: "Stardew Valley",
    price: 499, oldPrice: null, discount: 0,
    category: ["simulation", "indie"],
    tags: ["Симулятор", "Ферма", "Инди", "Уютная"],
    description: "Вы унаследовали старую ферму деда в Stardew Valley. Вооружившись подержанными инструментами и решимостью, вы отправляетесь в новую жизнь.\n\nМожно ли научиться жить за счёт земли и превратить заросшие поля в процветающую ферму? В этом вам помогут жители Пеликана — каждый со своей историей и характером.\n\nВыращивайте культуры, разводите животных, ловите рыбу, добывайте руду в шахтах, готовьте еду, крафтите предметы и заводите отношения (включая брак и детей).\n\nПоддержка кооператива до 4 игроков, моды, регулярные бесплатные обновления от автора ConcernedApe. Одна из самых тёплых и долгоиграющих инди-игр всех времён.",
    shortDesc: "Унаследуйте ферму деда и начните новую жизнь в уютной деревне Пеликан.",
    cover: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "26 фев. 2016",
    developer: "ConcernedApe", publisher: "ConcernedApe",
    rating: 4.9, reviews: 31200, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "6+", languages: ["Русский", "English", "中文"],
    sysReq: {
      min: "OS: Windows Vista+ · CPU: 2 GHz · RAM: 2 GB · GPU: 256 MB · Storage: 500 MB",
      rec: "OS: Windows 10+ · CPU: 3 GHz · RAM: 4 GB · GPU: 512 MB · Storage: 1 GB"
    }
  },
  {
    id: 4,
    title: "Counter-Strike 2",
    price: 0, oldPrice: null, discount: 0,
    category: ["action"],
    tags: ["Шутер", "Мультиплеер", "Бесплатно", "Киберспорт"],
    description: "Более двух десятилетий Counter-Strike остаётся эталоном командного тактического шутера. CS2 переносит серию на движок Source 2.\n\nУлучшенная графика, динамический дым, обновлённый звук и переработанные карты. Классические режимы: Competitive, Casual, Deathmatch, Wingman.\n\nИграйте с друзьями, участвуйте в матчмейкинге, смотрите турниры и торгуйте скинами. Бесплатный вход, огромное сообщество и постоянная поддержка Valve.",
    shortDesc: "Легендарный тактический шутер на Source 2. Бесплатно.",
    cover: "https://images.unsplash.com/photo-1542751110-97427bbecf20?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1542751110-97427bbecf20?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "27 сен. 2023",
    developer: "Valve", publisher: "Valve",
    rating: 4.3, reviews: 89000, platforms: ["Windows", "Linux"],
    ageRating: "16+", languages: ["Русский", "English", "и ещё 25+"],
    sysReq: {
      min: "OS: Windows 10 · CPU: 4 threads · RAM: 8 GB · GPU: DirectX 11 · Storage: 85 GB",
      rec: "OS: Windows 10/11 · CPU: 4+ threads · RAM: 12 GB · GPU: GTX 1050+ · Storage: 85 GB SSD"
    }
  },
  {
    id: 5,
    title: "Hades II",
    price: 1499, oldPrice: 1999, discount: 25,
    category: ["action", "indie", "rpg"],
    tags: ["Roguelike", "Инди", "Мифология", "Экшен"],
    description: "Битва за Олимп продолжается. Hades II — долгожданный сиквел отмеченного наградами roguelike от Supergiant Games.\n\nВы — Мелиноэ, бессмертная принцесса подземного мира, сестра Загрея. Хронос, Титан Времени, держит в плену вашу семью. Вам предстоит сражаться сквозь всё новые забеги, осваивая магию, оружие и благословения богов.\n\nКаждый забег уникален: случайные комнаты, боссы и комбинации способностей. Между попытками развивайте базу, общайтесь с персонажами и раскрывайте мифологическую историю.\n\nФирменный стиль Supergiant: потрясающий арт, саундтрек и проработанные персонажи.",
    shortDesc: "Сражайтесь с силами подземного мира в роли принцессы Мелиноэ.",
    cover: "https://images.unsplash.com/photo-1551103782-8ab62a2e8e6a?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1551103782-8ab62a2e8e6a?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1614294148960-9aa7406326c0?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1579373903781-fd5c0d1c7b5b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop&q=80"
    ],
    featured: true, release: "6 мая 2024",
    developer: "Supergiant Games", publisher: "Supergiant Games",
    rating: 4.7, reviews: 5600, platforms: ["Windows", "macOS"],
    ageRating: "12+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 10 · CPU: Dual Core 2.4 GHz · RAM: 4 GB · GPU: 2 GB VRAM · Storage: 10 GB",
      rec: "OS: Windows 10/11 · CPU: Quad Core · RAM: 8 GB · GPU: 4 GB VRAM · Storage: 10 GB SSD"
    }
  },
  {
    id: 6,
    title: "Baldur's Gate 3",
    price: 2999, oldPrice: 3999, discount: 25,
    category: ["rpg"],
    tags: ["RPG", "Турновая", "Фэнтези", "Кооператив"],
    description: "Соберите отряд и вернитесь в Забытые Королевства. Baldur's Gate 3 — RPG по правилам Dungeons & Dragons 5e от Larian Studios.\n\nВас похитили иллитиды и заразили паразитом. Вместе с уникальными компаньонами вы должны найти способ избавиться от угрозы — или принять её силу.\n\nГлубокая ролевая система: расы, классы, подклассы, заклинания, навыки. Решения имеют последствия, диалоги ветвятся, а бой — тактический и пошаговый.\n\nКооператив до 4 игроков, мощный редактор персонажа, сотни часов контента. Игра года по версии множества изданий.",
    shortDesc: "RPG по D&D 5e: дружба, предательство и выживание в Забытых Королевствах.",
    cover: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1614294148960-9aa7406326c0?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop&q=80"
    ],
    featured: true, release: "3 авг. 2023",
    developer: "Larian Studios", publisher: "Larian Studios",
    rating: 4.9, reviews: 18700, platforms: ["Windows", "macOS"],
    ageRating: "18+", languages: ["Русский", "English", "и ещё 10+"],
    sysReq: {
      min: "OS: Windows 10 64-bit · CPU: Intel i5-4690 / AMD FX-8350 · RAM: 8 GB · GPU: GTX 970 / RX 480 · Storage: 150 GB",
      rec: "OS: Windows 10/11 · CPU: Intel i7-8700K / AMD r5 3600 · RAM: 16 GB · GPU: RTX 2060 / RX 5700 XT · Storage: 150 GB SSD"
    }
  },
  {
    id: 7,
    title: "The Witcher 3: Wild Hunt",
    price: 599, oldPrice: 1999, discount: 70,
    category: ["rpg", "action", "adventure"],
    tags: ["RPG", "Открытый мир", "Фэнтези", "Сюжет"],
    description: "Вы — Геральт из Ривии, охотник на монстров. В мире, охваченном войной, вы преследуете дитя пророчества — Цири, которую ищет Дикая Охота.\n\nОгромный открытый мир: города, леса, острова, горы. Сотни квестов с моральным выбором, проработанные персонажи, боевая система с знаками, зельями и оружием.\n\nВключает дополнения Hearts of Stone и Blood and Wine. Next-Gen обновление добавило трассировку лучей, новые квесты и улучшения.\n\nОдна из лучших RPG в истории индустрии.",
    shortDesc: "Геральт из Ривии в поисках Цири. Эпическая RPG с открытым миром.",
    cover: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "19 мая 2015",
    developer: "CD PROJEKT RED", publisher: "CD PROJEKT RED",
    rating: 4.8, reviews: 45200, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "18+", languages: ["Русский", "English", "Polski"],
    sysReq: {
      min: "OS: Windows 7/8/10 64-bit · CPU: Intel i5-2500K / AMD Phenom II X4 · RAM: 6 GB · GPU: GTX 660 / HD 7870 · Storage: 50 GB",
      rec: "OS: Windows 10 · CPU: Intel i7 / AMD Ryzen · RAM: 8 GB · GPU: GTX 970 / R9 290 · Storage: 50 GB SSD"
    }
  },
  {
    id: 8,
    title: "Terraria",
    price: 399, oldPrice: null, discount: 0,
    category: ["adventure", "indie"],
    tags: ["Песочница", "Крафт", "2D", "Кооператив"],
    description: "Копайте, сражайтесь, исследуйте, стройте! В Terraria нет ничего невозможного.\n\n2D-песочница с элементами приключения, крафта и боёв с боссами. Собирайте ресурсы, создавайте оружие и броню, стройте дома и целые города, призывайте NPC.\n\nСотни врагов, десятки боссов, биомы от леса до ада. Кооператив и PvP. Постоянные обновления добавляют контент даже спустя годы после релиза.\n\nБолее 35 миллионов проданных копий.",
    shortDesc: "Копайте, стройте, сражайтесь в бесконечном 2D-мире.",
    cover: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "16 мая 2011",
    developer: "Re-Logic", publisher: "Re-Logic",
    rating: 4.8, reviews: 67800, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "12+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows XP+ · CPU: 2.0 GHz · RAM: 2.5 GB · GPU: 128 MB · Storage: 200 MB",
      rec: "OS: Windows 7+ · CPU: 3.0 GHz Dual Core · RAM: 4 GB · GPU: 256 MB · Storage: 500 MB"
    }
  },
  {
    id: 9,
    title: "Civilization VI",
    price: 899, oldPrice: 2999, discount: 70,
    category: ["strategy"],
    tags: ["Стратегия", "Пошаговая", "История", "4X"],
    description: "Создайте империю, которая выдержит испытание временем. Civilization VI — глубочайшая часть серии.\n\nОсновайте города, исследуйте технологии и культуру, ведите дипломатию, торговлю и войны. Побеждайте по науке, культуре, религии, дипломатии или господству.\n\nУникальные цивилизации и лидеры, районы городов, активные исследования, климатические изменения. Одиночная кампания и мультиплеер.",
    shortDesc: "Постройте империю от каменного века до будущего.",
    cover: "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "21 окт. 2016",
    developer: "Firaxis Games", publisher: "2K",
    rating: 4.6, reviews: 9800, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "12+", languages: ["Русский", "English"],
    sysReq: {
      min: "OS: Windows 7+ · CPU: Intel Core i3 2.5 GHz · RAM: 4 GB · GPU: 1 GB DirectX 11 · Storage: 12 GB",
      rec: "OS: Windows 10 · CPU: Intel Core i5 · RAM: 8 GB · GPU: 2 GB · Storage: 17 GB"
    }
  },
  {
    id: 10,
    title: "Hollow Knight",
    price: 499, oldPrice: null, discount: 0,
    category: ["adventure", "indie", "action"],
    tags: ["Metroidvania", "Инди", "2D", "Сложный"],
    description: "Исследуйте огромное разрушенное королевство насекомых и героев. Под землёй ждёт древний мир, полный чудес и ужасов.\n\nHollow Knight — классическая metroidvania: связные локации, способности, открывающие новые пути, боссы и секреты. Атмосферный мир, рукописная графика и запоминающийся саундтрек.\n\nСражайтесь с насекомыми-воинами, раскрывайте тайны Халлоунеста и станьте легендой. Одна из лучших 2D-игр поколения.",
    shortDesc: "Исследуйте королевство насекомых в шедевральной metroidvania.",
    cover: "https://images.unsplash.com/photo-1551103782-8ab62a2e8e6a?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1551103782-8ab62a2e8e6a?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1614294148960-9aa7406326c0?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1579373903781-fd5c0d1c7b5b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "24 фев. 2017",
    developer: "Team Cherry", publisher: "Team Cherry",
    rating: 4.9, reviews: 22300, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "6+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 7 · CPU: Dual Core 2 GHz · RAM: 4 GB · GPU: DirectX 10 · Storage: 9 GB",
      rec: "OS: Windows 10 · CPU: Dual Core 3 GHz · RAM: 8 GB · GPU: DirectX 11 · Storage: 9 GB"
    }
  },
  {
    id: 11,
    title: "Red Dead Redemption 2",
    price: 1499, oldPrice: 3999, discount: 63,
    category: ["action", "adventure"],
    tags: ["Открытый мир", "Вестерн", "Сюжет", "Реализм"],
    description: "Америка, 1899 год. Эпоха Дикого Запада подходит к концу. Артур Морган и банда Датча ван дер Линде вынуждены бежать. Федералы и лучшие охотники за головами идут по пятам.\n\nRed Dead Redemption 2 — эпическая история о чести и верности в угасающем мире. Невероятная детализация: от поведения лошадей до погоды и экономики.\n\nОдиночная кампания на десятки часов и онлайн-режим Red Dead Online. Охота, рыбалка, ограбления, дуэли.\n\nШедевр Rockstar Games.",
    shortDesc: "Эпический вестерн о банде вне закона на закате Дикого Запада.",
    cover: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "5 дек. 2019",
    developer: "Rockstar Games", publisher: "Rockstar Games",
    rating: 4.7, reviews: 35600, platforms: ["Windows"],
    ageRating: "18+", languages: ["Русский", "English"],
    sysReq: {
      min: "OS: Windows 10 · CPU: Intel Core i5-2500K / AMD FX-6300 · RAM: 8 GB · GPU: GTX 770 2GB / Radeon R9 280 · Storage: 150 GB",
      rec: "OS: Windows 10 · CPU: Intel Core i7-4770K / AMD Ryzen 5 1500X · RAM: 12 GB · GPU: GTX 1060 6GB / RX 480 4GB · Storage: 150 GB SSD"
    }
  },
  {
    id: 12,
    title: "Factorio",
    price: 1299, oldPrice: null, discount: 0,
    category: ["strategy", "simulation", "indie"],
    tags: ["Автоматизация", "Стратегия", "Инди", "Строительство"],
    description: "Factorio — игра об автоматизации. Вы разбились на чужой планете и должны добывать ресурсы, исследовать технологии, строить заводы и защищаться от местных существ.\n\nНачните с ручной добычи и дойдите до огромных фабрик с конвейерами, роботами и поездами. Оптимизация производства — главный кайф.\n\nКооператив, песочница, сценарии, мастерская модов. Игра, в которую «ещё на 5 минут» превращается в 5 часов.",
    shortDesc: "Стройте заводы, автоматизируйте всё и защищайтесь от кусак.",
    cover: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1563770660941-20978e870e26?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "14 авг. 2020",
    developer: "Wube Software", publisher: "Wube Software",
    rating: 4.9, reviews: 14200, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "6+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 10 · CPU: Dual core 3 GHz · RAM: 4 GB · GPU: 512 MB · Storage: 3 GB",
      rec: "OS: Windows 10/11 · CPU: Quad core 3+ GHz · RAM: 8 GB · GPU: 2 GB · Storage: 4 GB"
    }
  },
  {
    id: 13,
    title: "Portal 2",
    price: 299, oldPrice: 999, discount: 70,
    category: ["adventure", "action"],
    tags: ["Головоломка", "Научная фантастика", "Кооп", "Юмор"],
    description: "Одиночная и кооперативная кампания Portal 2 расширяют вселенную оригинала. Создавайте порталы, решайте головоломки и снова встретьтесь с GLaDOS.\n\nНовые механики: гели, лазеры, мосты из света, воронки. Острый юмор, запоминающиеся персонажи и идеальный дизайн уровней.\n\nКооператив на двух человек — отдельная история. Редактор уровней и мастерская Steam. Классика Valve, которая не стареет.",
    shortDesc: "Порталы, головоломки и GLaDOS. Культовый шедевр Valve.",
    cover: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "19 апр. 2011",
    developer: "Valve", publisher: "Valve",
    rating: 4.9, reviews: 51200, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "12+", languages: ["Русский", "English"],
    sysReq: {
      min: "OS: Windows 7+ · CPU: 3.0 GHz · RAM: 2 GB · GPU: 512 MB · Storage: 8 GB",
      rec: "OS: Windows 10 · CPU: Dual Core · RAM: 4 GB · GPU: 1 GB · Storage: 8 GB"
    }
  },
  {
    id: 14,
    title: "Among Us",
    price: 0, oldPrice: null, discount: 0,
    category: ["indie", "action"],
    tags: ["Мультиплеер", "Социальная", "Бесплатно", "Вечеринка"],
    description: "Играйте с 4–15 игроками онлайн или по локальной сети. Выполняйте задания на космическом корабле, базе или других картах.\n\nНо среди экипажа есть самозванцы. Они саботируют системы и устраняют членов экипажа. Обсуждайте, голосуйте, блефуйте — или устраивайте хаос, если вы предатель.\n\nПростая в освоении, бесконечно весёлая с друзьями. Кроссплатформенный мультиплеер, кастомизация, роли и карты.",
    shortDesc: "Кто самозванец? Социальная дедукция в космосе.",
    cover: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518770660439-4636190af475?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "15 июн. 2018",
    developer: "Innersloth", publisher: "Innersloth",
    rating: 4.2, reviews: 42100, platforms: ["Windows", "macOS"],
    ageRating: "6+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 7+ · CPU: 1.8 GHz · RAM: 1 GB · GPU: 256 MB · Storage: 250 MB",
      rec: "OS: Windows 10 · CPU: 2.5 GHz · RAM: 2 GB · GPU: 512 MB · Storage: 250 MB"
    }
  },
  {
    id: 15,
    title: "Disco Elysium",
    price: 799, oldPrice: 1599, discount: 50,
    category: ["rpg", "adventure", "indie"],
    tags: ["RPG", "Детектив", "Нарратив", "Инди"],
    description: "Disco Elysium — новаторская RPG, где главный инструмент — ваш разум. Вы — детектив с амнезией в городе на грани коллапса.\n\nУникальная система из 24 навыков, которые спорят друг с другом. Нет боёв в классическом смысле: расследование, диалоги и выборы.\n\nПисательский уровень текста, политические и философские темы, чёрный юмор. The Final Cut добавил полную озвучку и новый контент.\n\nИгра, которую стоит пройти хотя бы раз в жизни.",
    shortDesc: "Детектив с амнезией. RPG, где навыки спорят в вашей голове.",
    cover: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1455885667046-87a2e5e8c3c5?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "15 окт. 2019",
    developer: "ZA/UM", publisher: "ZA/UM",
    rating: 4.8, reviews: 8900, platforms: ["Windows", "macOS"],
    ageRating: "18+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 7 · CPU: Dual Core 2 GHz · RAM: 4 GB · GPU: 1 GB · Storage: 20 GB",
      rec: "OS: Windows 10 · CPU: Dual Core 2.5 GHz · RAM: 8 GB · GPU: 2 GB · Storage: 20 GB"
    }
  },
  {
    id: 16,
    title: "Cities: Skylines II",
    price: 2499, oldPrice: null, discount: 0,
    category: ["simulation", "strategy"],
    tags: ["Симулятор", "Градостроительство", "Стратегия"],
    description: "Стройте город мечты. Cities: Skylines II — самая амбициозная симуляция города от Colossal Order.\n\nУлучшенная экономика, реалистичный трафик, смена времён года, глубокая система обслуживания и огромные масштабы. От крошечного посёлка до мегаполиса.\n\nМоды, ассеты, сценарии. Серия известна одним из лучших сообществ моддеров.",
    shortDesc: "Самая реалистичная симуляция города. Стройте без границ.",
    cover: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "24 окт. 2023",
    developer: "Colossal Order", publisher: "Paradox Interactive",
    rating: 4.0, reviews: 4200, platforms: ["Windows"],
    ageRating: "6+", languages: ["Русский", "English"],
    sysReq: {
      min: "OS: Windows 10 · CPU: Intel i5-4690K / AMD Ryzen 3 · RAM: 8 GB · GPU: GTX 970 / RX 480 · Storage: 60 GB",
      rec: "OS: Windows 10/11 · CPU: Intel i7-6700K / AMD Ryzen 5 · RAM: 16 GB · GPU: RTX 2070 / RX 6700 XT · Storage: 60 GB SSD"
    }
  },
  {
    id: 17,
    title: "Dota 2",
    price: 0, oldPrice: null, discount: 0,
    category: ["action", "strategy"],
    tags: ["MOBA", "Мультиплеер", "Бесплатно", "Киберспорт"],
    description: "Ежедневная борьба за Древних. Dota 2 — бесплатная MOBA с глубочайшей стратегией, сотнями героев и постоянными обновлениями от Valve.\n\nДве команды по 5 игроков уничтожают базу противника. Выбор героя, предметы, фарм, тимплей — бесконечная глубина.\n\nThe International — один из крупнейших киберспортивных турниров. Боевой пропуск, кастомные игры, турнирный клиент.",
    shortDesc: "Легендарная MOBA. 100+ героев. Бесплатно.",
    cover: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "9 июл. 2013",
    developer: "Valve", publisher: "Valve",
    rating: 4.4, reviews: 125000, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "12+", languages: ["Русский", "English", "и ещё 25+"],
    sysReq: {
      min: "OS: Windows 7+ · CPU: Dual core · RAM: 4 GB · GPU: DirectX 9 · Storage: 60 GB",
      rec: "OS: Windows 10 · CPU: Quad core · RAM: 8 GB · GPU: DirectX 11 · Storage: 60 GB"
    }
  },
  {
    id: 18,
    title: "Celeste",
    price: 599, oldPrice: null, discount: 0,
    category: ["indie", "adventure", "action"],
    tags: ["Платформер", "Инди", "Сложный", "Сюжет"],
    description: "Помогите Мэдлин преодолеть гору Селеста — и свои внутренние демоны. Точный и честный платформер о тревоге, решимости и принятии себя.\n\nСотни экранов, секреты, сбор коллекций, B-side и C-side уровни. Помощные режимы делают игру доступной.\n\nСаундтрек Lena Raine — отдельный шедевр. Победитель множества наград, включая The Game Awards.",
    shortDesc: "Покорите гору и себя в идеальном платформере.",
    cover: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "25 янв. 2018",
    developer: "Maddy Makes Games", publisher: "Maddy Makes Games",
    rating: 4.9, reviews: 15600, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "6+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 7 · CPU: Dual Core · RAM: 2 GB · GPU: DirectX 10 · Storage: 1.2 GB",
      rec: "OS: Windows 10 · CPU: Dual Core · RAM: 4 GB · GPU: DirectX 11 · Storage: 1.2 GB"
    }
  },
  {
    id: 19,
    title: "Resident Evil 4 Remake",
    price: 2799, oldPrice: 3999, discount: 30,
    category: ["action", "adventure"],
    tags: ["Хоррор", "Шутер", "Сюжет", "Ремейк"],
    description: "Выживание стало ещё страшнее. Ремейк легендарного Resident Evil 4 на современном движке RE Engine.\n\nЛеон С. Кеннеди отправляется спасти дочь президента — и попадает в кошмар европейской деревни. Переработанная боевая система, графика, саундтрек и кат-сцены.\n\nСохранён дух оригинала 2005 года с современным удобством управления. Один из лучших ремейков в истории.",
    shortDesc: "Леон против ужаса. Ремейк классики survival-horror.",
    cover: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=640&h=360&fit=crop&q=80"
    ],
    featured: true, release: "24 мар. 2023",
    developer: "Capcom", publisher: "Capcom",
    rating: 4.8, reviews: 11200, platforms: ["Windows"],
    ageRating: "18+", languages: ["Русский", "English", "日本語"],
    sysReq: {
      min: "OS: Windows 10 64-bit · CPU: AMD Ryzen 3 1200 / Intel i5-7500 · RAM: 8 GB · GPU: GTX 1050 Ti / RX 560 · Storage: 60 GB",
      rec: "OS: Windows 10/11 · CPU: AMD Ryzen 5 3600 / Intel i7-8700 · RAM: 16 GB · GPU: RTX 2060 / RX 5700 XT · Storage: 60 GB SSD"
    }
  },
  {
    id: 20,
    title: "Slay the Spire",
    price: 799, oldPrice: 999, discount: 20,
    category: ["indie", "strategy", "rpg"],
    tags: ["Roguelike", "Карточная", "Инди", "Стратегия"],
    description: "Объедините сотни карт и реликвий в уникальные колоды и сразитесь с монстрами в этом roguelike с колодостроением.\n\nЧетыре персонажа с разным стилем. Каждый забег — новый путь: события, магазины, элиты, боссы. Проигрыш — часть обучения.\n\nВысокая реиграбельность, баланс, моды. Одна из игр, определивших жанр deck-building roguelike.",
    shortDesc: "Собирайте колоду, побеждайте монстров, умрите, повторите.",
    cover: "https://images.unsplash.com/photo-1611996575749-79a3a250f948?w=460&h=215&fit=crop&q=80",
    coverLarge: "https://images.unsplash.com/photo-1611996575749-79a3a250f948?w=920&h=430&fit=crop&q=80",
    screenshots: [
      "https://images.unsplash.com/photo-1606503153255-59d5e15497e0?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=640&h=360&fit=crop&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=640&h=360&fit=crop&q=80"
    ],
    featured: false, release: "23 янв. 2019",
    developer: "Mega Crit Games", publisher: "Mega Crit Games",
    rating: 4.8, reviews: 18900, platforms: ["Windows", "macOS", "Linux"],
    ageRating: "12+", languages: ["English", "Русский"],
    sysReq: {
      min: "OS: Windows 7 · CPU: 2 GHz · RAM: 2 GB · GPU: 1 GB · Storage: 1 GB",
      rec: "OS: Windows 10 · CPU: 3 GHz · RAM: 4 GB · GPU: 2 GB · Storage: 1 GB"
    }
  }
];

const ACHIEVEMENTS = [
  { id: "first_buy", title: "Первая покупка", desc: "Купите свою первую игру", icon: "🛒" },
  { id: "collector", title: "Коллекционер", desc: "Соберите 5 игр в библиотеке", icon: "📚" },
  { id: "wishlist_king", title: "Мечтатель", desc: "Добавьте 3 игры в список желаемого", icon: "⭐" },
  { id: "big_spender", title: "Щедрая душа", desc: "Потратьте более 5000 ₽", icon: "💰" },
  { id: "night_owl", title: "Ночная сова", desc: "Зайдите в магазин после полуночи", icon: "🦉" },
  { id: "reviewer", title: "Критик", desc: "Оставьте отзыв об игре", icon: "✍️" },
  { id: "social", title: "Общительный", desc: "Откройте раздел Сообщество", icon: "💬" },
  { id: "explorer", title: "Исследователь", desc: "Откройте 10 страниц игр", icon: "🗺️" }
];

const AVATAR_COLORS = [
  "linear-gradient(135deg, #667eea, #764ba2)",
  "linear-gradient(135deg, #f093fb, #f5576c)",
  "linear-gradient(135deg, #4facfe, #00f2fe)",
  "linear-gradient(135deg, #43e97b, #38f9d7)",
  "linear-gradient(135deg, #fa709a, #fee140)",
  "linear-gradient(135deg, #a18cd1, #fbc2eb)",
  "linear-gradient(135deg, #ff9a9e, #fecfef)",
  "linear-gradient(135deg, #66c0f4, #1a9fff)"
];

const PLACEHOLDER = (title, w, h) =>
  "https://placehold.co/" + w + "x" + h + "/1b2838/66c0f4/png?text=" + encodeURIComponent(title.slice(0, 18));
