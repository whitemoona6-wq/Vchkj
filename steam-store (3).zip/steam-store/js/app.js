/* ===== State ===== */
const state = {
  cart: JSON.parse(localStorage.getItem('gs_cart') || '[]'),
  library: JSON.parse(localStorage.getItem('gs_library') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('gs_wishlist') || '[]'),
  user: JSON.parse(localStorage.getItem('gs_user') || 'null'),
  playtimes: JSON.parse(localStorage.getItem('gs_playtimes') || '{}'),
  spent: JSON.parse(localStorage.getItem('gs_spent') || '0'),
  achievements: JSON.parse(localStorage.getItem('gs_achievements') || '[]'),
  activity: JSON.parse(localStorage.getItem('gs_activity') || '[]'),
  currentCategory: 'all',
  searchQuery: '',
  sortBy: 'popular',
  authMode: 'login',
  heroIndex: 0,
  profileTab: 'overview'
};

const FEATURED = GAMES.filter(g => g.featured);
let heroTimer = null;

/* ===== Helpers ===== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function formatPrice(n) {
  if (n === 0) return 'Бесплатно';
  return n.toLocaleString('ru-RU') + ' ₽';
}

function formatNum(n) {
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(n);
}

function save(key, val) {
  localStorage.setItem(key, typeof val === 'string' ? val : JSON.stringify(val));
}

function saveAll() {
  save('gs_cart', state.cart);
  save('gs_library', state.library);
  save('gs_wishlist', state.wishlist);
  save('gs_user', state.user);
  save('gs_playtimes', state.playtimes);
  save('gs_spent', state.spent);
  save('gs_achievements', state.achievements);
  save('gs_activity', state.activity);
  updateBadges();
}

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2800);
}

function getGame(id) {
  return GAMES.find(g => g.id === id);
}

function addActivity(text) {
  state.activity.unshift({
    text,
    time: new Date().toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
  });
  if (state.activity.length > 20) state.activity.pop();
}

function checkAchievements() {
  const unlock = (id) => {
    if (!state.achievements.includes(id)) {
      state.achievements.push(id);
      const a = ACHIEVEMENTS.find(x => x.id === id);
      if (a) toast(`🏆 Достижение: ${a.title}`);
    }
  };
  if (state.library.length >= 1) unlock('first_buy');
  if (state.library.length >= 5) unlock('collector');
  if (state.wishlist.length >= 3) unlock('wishlist_king');
  if (state.spent >= 5000) unlock('big_spender');
  const h = new Date().getHours();
  if (h >= 0 && h < 5) unlock('night_owl');
}

function getLevel() {
  const xp = state.library.length * 50 + state.wishlist.length * 10 + state.spent / 100 + state.achievements.length * 30;
  const level = Math.min(50, Math.floor(xp / 100) + 1);
  const progress = xp % 100;
  return { level, progress, xp: Math.floor(xp) };
}

function coverStyle(game) {
  return `background-image:url('${game.cover}');background-color:#1a2a3a`;
}

function coverImg(game, w, h) {
  const src = game.cover || '';
  const fb = typeof PLACEHOLDER === 'function' ? PLACEHOLDER(game.title, w || 460, h || 215) : '';
  return `<img src="${src}" alt="${game.title}" loading="lazy" onerror="this.onerror=null;this.src='${fb}'" />`;
}

/* ===== Game Card ===== */
function createGameCard(game) {
  const card = document.createElement('div');
  card.className = 'game-card';
  card.dataset.id = game.id;

  const inWl = state.wishlist.includes(game.id);
  const priceHtml = game.price === 0
    ? `<span class="price-free">Бесплатно</span>`
    : `
      ${game.discount ? `<span class="price-discount">-${game.discount}%</span>` : ''}
      ${game.oldPrice ? `<span class="price-old">${formatPrice(game.oldPrice)}</span>` : ''}
      <span class="price-current">${formatPrice(game.price)}</span>
    `;

  card.innerHTML = `
    <div class="game-cover">
      ${coverImg(game, 460, 215)}
      <button class="card-wishlist ${inWl ? 'active' : ''}" data-id="${game.id}" title="В желаемое">★</button>
    </div>
    <div class="game-info">
      <div class="game-title">${game.title}</div>
      <div class="game-tags">${game.tags.slice(0, 2).map(t => `<span class="game-tag">${t}</span>`).join('')}</div>
      <div class="game-price-row">${priceHtml}</div>
      <div class="game-rating">★ ${game.rating} · ${formatNum(game.reviews)} отзывов</div>
    </div>
  `;

  card.addEventListener('click', (e) => {
    if (e.target.closest('.card-wishlist')) return;
    openGameDetail(game.id);
  });

  card.querySelector('.card-wishlist').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleWishlist(game.id);
    e.target.classList.toggle('active', state.wishlist.includes(game.id));
  });

  return card;
}

/* ===== Filter & Sort ===== */
function getFilteredGames() {
  let list = GAMES.filter(g => {
    const catOk = state.currentCategory === 'all' || g.category.includes(state.currentCategory);
    const q = state.searchQuery.toLowerCase();
    const searchOk = !q || g.title.toLowerCase().includes(q) || g.tags.some(t => t.toLowerCase().includes(q));
    return catOk && searchOk;
  });

  switch (state.sortBy) {
    case 'price-asc': list.sort((a, b) => a.price - b.price); break;
    case 'price-desc': list.sort((a, b) => b.price - a.price); break;
    case 'discount': list.sort((a, b) => b.discount - a.discount); break;
    case 'rating': list.sort((a, b) => b.rating - a.rating); break;
    case 'name': list.sort((a, b) => a.title.localeCompare(b.title, 'ru')); break;
    default: list.sort((a, b) => b.reviews - a.reviews);
  }
  return list;
}

function renderStore() {
  const filtered = getFilteredGames();
  const offers = filtered.filter(g => g.discount > 0);

  const offersRow = $('#offers-row');
  offersRow.innerHTML = '';
  if (offers.length === 0) {
    offersRow.innerHTML = '<p style="color:var(--text-muted);padding:16px 0">Нет предложений</p>';
  } else {
    offers.forEach(g => offersRow.appendChild(createGameCard(g)));
  }
  $('#offers-count').textContent = offers.length ? `${offers.length}` : '';

  const grid = $('#games-grid');
  grid.innerHTML = '';
  if (filtered.length === 0) {
    grid.innerHTML = '<p style="color:var(--text-muted);grid-column:1/-1;padding:40px 0;text-align:center">Игры не найдены</p>';
  } else {
    filtered.forEach(g => grid.appendChild(createGameCard(g)));
  }
  $('#catalog-count').textContent = `${filtered.length} игр`;
}

/* ===== Hero carousel ===== */
function setupHero() {
  const games = FEATURED.length ? FEATURED : GAMES.slice(0, 4);
  renderHero(games[state.heroIndex % games.length]);

  const dots = $('#hero-dots');
  dots.innerHTML = games.map((_, i) =>
    `<div class="hero-dot ${i === state.heroIndex % games.length ? 'active' : ''}" data-i="${i}"></div>`
  ).join('');

  dots.querySelectorAll('.hero-dot').forEach(d => {
    d.onclick = () => {
      state.heroIndex = +d.dataset.i;
      renderHero(games[state.heroIndex]);
      dots.querySelectorAll('.hero-dot').forEach((x, i) => x.classList.toggle('active', i === state.heroIndex));
      resetHeroTimer(games);
    };
  });

  resetHeroTimer(games);
}

function renderHero(game) {
  const heroUrl = game.coverLarge || game.cover;
  const img = new Image();
  img.onload = () => { $('#hero-bg').style.backgroundImage = `url('${heroUrl}')`; };
  img.onerror = () => { $('#hero-bg').style.backgroundImage = `url('${PLACEHOLDER(game.title, 920, 430)}')`; };
  img.src = heroUrl;
  $('#hero-title').textContent = game.title;
  $('#hero-desc').textContent = game.shortDesc || game.description.slice(0, 160);
  $('#hero-price').textContent = formatPrice(game.price);
  if (game.discount) {
    $('#hero-discount').textContent = `-${game.discount}%`;
    $('#hero-discount').style.display = '';
    $('#hero-old-price').textContent = formatPrice(game.oldPrice);
    $('#hero-old-price').style.display = '';
  } else {
    $('#hero-discount').style.display = 'none';
    $('#hero-old-price').style.display = 'none';
  }
  $('#hero-buy').onclick = () => addToCart(game.id);
  $('#hero-wishlist').onclick = () => toggleWishlist(game.id);
}

function resetHeroTimer(games) {
  clearInterval(heroTimer);
  heroTimer = setInterval(() => {
    state.heroIndex = (state.heroIndex + 1) % games.length;
    renderHero(games[state.heroIndex]);
    $$('.hero-dot').forEach((x, i) => x.classList.toggle('active', i === state.heroIndex));
  }, 6000);
}

/* ===== Game Detail ===== */
function openGameDetail(id) {
  const game = getGame(id);
  if (!game) return;

  const owned = state.library.includes(id);
  const inCart = state.cart.includes(id);
  const inWl = state.wishlist.includes(id);

  const priceHtml = game.price === 0
    ? `<span class="price-current" style="font-size:18px;color:var(--green)">Бесплатно</span>`
    : `
      ${game.discount ? `<span class="price-discount">-${game.discount}%</span>` : ''}
      ${game.oldPrice ? `<span class="price-old">${formatPrice(game.oldPrice)}</span>` : ''}
      <span class="price-current" style="font-size:18px">${formatPrice(game.price)}</span>
    `;

  let actionBtn;
  if (owned) {
    actionBtn = `<button class="btn btn-primary btn-block" disabled>Уже в библиотеке</button>`;
  } else if (inCart) {
    actionBtn = `<button class="btn btn-secondary btn-block" id="detail-in-cart">Уже в корзине</button>`;
  } else {
    actionBtn = `<button class="btn btn-primary btn-block" id="detail-buy">${game.price === 0 ? 'Получить' : 'В корзину'}</button>`;
  }

  const mockReviews = [
    { author: 'PlayerOne', stars: 5, text: 'Отличная игра, рекомендую всем!' },
    { author: 'GamerGirl', stars: 4, text: 'Крутой сюжет, иногда баги, но в целом супер.' },
    { author: 'NightOwl', stars: 5, text: 'Прошёл на 100%. Шедевр.' }
  ];

  $('#game-detail').innerHTML = `
    <div class="game-detail-header">
      <div>
        <div class="game-detail-media" id="detail-media">
          <img src="${game.coverLarge || game.cover}" alt="${game.title}" id="detail-main-img"
            onerror="this.onerror=null;this.src=PLACEHOLDER('${game.title.replace(/'/g, '')}',920,430)" />
        </div>
        <div class="screenshots-row" id="detail-shots">
          ${(game.screenshots || []).map((s, i) =>
            `<img src="${s}" alt="" data-src="${s}" class="${i === 0 ? 'active' : ''}" loading="lazy"
              onerror="this.onerror=null;this.src=PLACEHOLDER('${game.title.replace(/'/g,"")}',640,360)" />`
          ).join('')}
        </div>
      </div>
      <div class="game-detail-sidebar">
        <div class="cover-mini">${coverImg(game, 320, 140)}</div>
        <h1>${game.title}</h1>
        <div class="tags">${game.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
        <div class="detail-price-block">
          <div class="detail-price-row">${priceHtml}</div>
          <div class="detail-actions">
            ${actionBtn}
            <button class="btn btn-secondary btn-block" id="detail-wishlist">${inWl ? '★ В желаемом' : '☆ В желаемое'}</button>
          </div>
        </div>
        <div class="detail-meta">
          <div><span>Дата выхода</span><span>${game.release}</span></div>
          <div><span>Разработчик</span><span>${game.developer}</span></div>
          <div><span>Издатель</span><span>${game.publisher}</span></div>
          <div><span>Платформы</span><span>${(game.platforms || []).join(', ')}</span></div>
          <div><span>Оценка</span><span>★ ${game.rating} (${formatNum(game.reviews)})</span></div>
          <div><span>Возраст</span><span>${game.ageRating || '—'}</span></div>
          <div><span>Языки</span><span>${(game.languages || []).slice(0,3).join(', ')}</span></div>
        </div>
      </div>
    </div>
    <div class="game-description">
      <h2>Об этой игре</h2>
      ${game.description.split('\n').filter(Boolean).map(p => `<p>${p}</p>`).join('')}
    </div>
    ${game.sysReq ? `
    <div class="game-description" style="margin-top:16px">
      <h2>Системные требования</h2>
      <div class="sys-req">
        <div class="sys-col">
          <h4>Минимальные</h4>
          <p>${game.sysReq.min}</p>
        </div>
        <div class="sys-col">
          <h4>Рекомендуемые</h4>
          <p>${game.sysReq.rec}</p>
        </div>
      </div>
    </div>` : ''}
    <div class="game-description" style="margin-top:16px">
      <h2>Похожие игры</h2>
      <div class="games-row" id="similar-games"></div>
    </div>
    <div class="reviews-section">
      <h2>Отзывы</h2>
      <div class="review-summary">
        <div class="review-score">${game.rating}</div>
        <div>
          <div style="color:var(--gold)">${'★'.repeat(Math.round(game.rating))}${'☆'.repeat(5 - Math.round(game.rating))}</div>
          <div class="review-count">${formatNum(game.reviews)} отзывов</div>
        </div>
      </div>
      ${mockReviews.map(r => `
        <div class="review-item">
          <div class="author">${r.author}</div>
          <div class="stars">${'★'.repeat(r.stars)}</div>
          <div class="text">${r.text}</div>
        </div>
      `).join('')}
    </div>
  `;

  $('#detail-buy')?.addEventListener('click', () => {
    addToCart(id);
    openGameDetail(id);
  });

  $('#detail-wishlist')?.addEventListener('click', () => {
    toggleWishlist(id);
    openGameDetail(id);
  });

  $$('#detail-shots img').forEach(img => {
    img.onclick = () => {
      const main = $('#detail-main-img');
      if (main) main.src = img.dataset.src;
      else $('#detail-media').style.backgroundImage = `url('${img.dataset.src}')`;
      $$('#detail-shots img').forEach(x => x.classList.remove('active'));
      img.classList.add('active');
    };
  });

  // Similar games
  const similar = GAMES.filter(g => g.id !== id && g.category.some(c => game.category.includes(c))).slice(0, 6);
  const simEl = $('#similar-games');
  if (simEl) similar.forEach(g => simEl.appendChild(createGameCard(g)));

  // Track viewed for explorer achievement
  if (!state.viewed) state.viewed = JSON.parse(localStorage.getItem('gs_viewed') || '[]');
  if (!state.viewed.includes(id)) {
    state.viewed.push(id);
    localStorage.setItem('gs_viewed', JSON.stringify(state.viewed));
    if (state.viewed.length >= 10) {
      if (!state.achievements.includes('explorer')) {
        state.achievements.push('explorer');
        saveAll();
        toast('🏆 Достижение: Исследователь');
      }
    }
  }

  showPage('game');
}

/* ===== Cart ===== */
function addToCart(id) {
  if (state.library.includes(id)) { toast('Игра уже в библиотеке'); return; }
  if (state.cart.includes(id)) { toast('Уже в корзине'); return; }
  state.cart.push(id);
  saveAll();
  toast('Добавлено в корзину');
}

function removeFromCart(id) {
  state.cart = state.cart.filter(x => x !== id);
  saveAll();
  renderCartItems();
}

function updateBadges() {
  const cartBadge = $('#cart-count');
  cartBadge.textContent = state.cart.length;
  cartBadge.classList.toggle('show', state.cart.length > 0);

  const wlBadge = $('#wishlist-count');
  wlBadge.textContent = state.wishlist.length;
  wlBadge.classList.toggle('show', state.wishlist.length > 0);
}

function renderCartItems() {
  const container = $('#cart-items');
  if (state.cart.length === 0) {
    container.innerHTML = '<div class="cart-empty">Корзина пуста</div>';
    $('#cart-total').textContent = '0 ₽';
    return;
  }
  let total = 0;
  container.innerHTML = state.cart.map(id => {
    const g = getGame(id);
    if (!g) return '';
    total += g.price;
    return `
      <div class="cart-item">
        <div class="cart-item-cover">${coverImg(g, 80, 46)}</div>
        <div class="cart-item-info">
          <h4>${g.title}</h4>
          <div class="price">${formatPrice(g.price)}</div>
        </div>
        <button class="cart-item-remove" data-id="${g.id}">×</button>
      </div>
    `;
  }).join('');
  $('#cart-total').textContent = formatPrice(total);
  $$('.cart-item-remove', container).forEach(btn => {
    btn.onclick = () => removeFromCart(+btn.dataset.id);
  });
}

function openCart() {
  renderCartItems();
  $('#cart-sidebar').classList.add('open');
  $('#overlay').classList.add('open');
}

function closeCart() {
  $('#cart-sidebar').classList.remove('open');
  $('#overlay').classList.remove('open');
}

function checkout() {
  if (state.cart.length === 0) { toast('Корзина пуста'); return; }
  if (!state.user) { toast('Войдите, чтобы оформить покупку'); openAuth('login'); return; }

  let total = 0;
  state.cart.forEach(id => {
    const g = getGame(id);
    if (g) total += g.price;
    if (!state.library.includes(id)) state.library.push(id);
    if (!state.playtimes[id]) state.playtimes[id] = Math.floor(Math.random() * 5) + 1;
    state.wishlist = state.wishlist.filter(w => w !== id);
  });
  state.spent = (Number(state.spent) || 0) + total;
  addActivity(`Куплено игр: ${state.cart.length} на ${formatPrice(total)}`);
  state.cart = [];
  checkAchievements();
  saveAll();
  closeCart();
  toast('Покупка оформлена! Игры в библиотеке.');
  renderLibrary();
}

/* ===== Wishlist ===== */
function toggleWishlist(id) {
  if (state.library.includes(id)) { toast('Игра уже в библиотеке'); return; }
  const idx = state.wishlist.indexOf(id);
  if (idx >= 0) {
    state.wishlist.splice(idx, 1);
    toast('Удалено из желаемого');
  } else {
    state.wishlist.push(id);
    toast('Добавлено в желаемое');
    addActivity(`В желаемое: ${getGame(id)?.title || id}`);
  }
  checkAchievements();
  saveAll();
  if ($('#page-wishlist')?.classList.contains('active')) renderWishlist();
}

function renderWishlist() {
  const grid = $('#wishlist-grid');
  const empty = $('#wishlist-empty');
  $('#wishlist-page-count').textContent = state.wishlist.length ? `${state.wishlist.length}` : '';

  if (state.wishlist.length === 0) {
    grid.innerHTML = '';
    grid.appendChild(empty);
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';
  grid.innerHTML = '';
  state.wishlist.forEach(id => {
    const g = getGame(id);
    if (!g) return;
    const card = document.createElement('div');
    card.className = 'wishlist-card';
    card.innerHTML = `
      <div class="wishlist-cover">${coverImg(g, 120, 70)}</div>
      <div class="wishlist-info">
        <h3>${g.title}</h3>
        <div class="meta">${formatPrice(g.price)}${g.discount ? ` · -${g.discount}%` : ''}</div>
        <div class="wl-actions">
          <button class="btn btn-primary btn-sm wl-buy">В корзину</button>
          <button class="btn btn-danger btn-sm wl-remove">Удалить</button>
        </div>
      </div>
    `;
    card.querySelector('.wl-buy').onclick = (e) => { e.stopPropagation(); addToCart(id); };
    card.querySelector('.wl-remove').onclick = (e) => { e.stopPropagation(); toggleWishlist(id); };
    card.onclick = () => openGameDetail(id);
    grid.appendChild(card);
  });
}

/* ===== Library ===== */
function renderLibrary() {
  const grid = $('#library-grid');
  const empty = $('#library-empty');

  if (state.library.length === 0) {
    grid.innerHTML = '';
    grid.appendChild(empty);
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  const q = ($('#library-search')?.value || '').toLowerCase();
  const sort = $('#library-sort')?.value || 'name';
  let games = state.library.map(id => getGame(id)).filter(Boolean);
  if (q) games = games.filter(g => g.title.toLowerCase().includes(q));
  if (sort === 'name') games.sort((a, b) => a.title.localeCompare(b.title, 'ru'));
  else if (sort === 'playtime') games.sort((a, b) => (state.playtimes[b.id] || 0) - (state.playtimes[a.id] || 0));

  grid.innerHTML = '';
  games.forEach(g => {
    const pt = state.playtimes[g.id] || Math.floor(Math.random() * 30) + 1;
    state.playtimes[g.id] = pt;
    const card = document.createElement('div');
    card.className = 'library-card';
    card.innerHTML = `
      <div class="library-cover">${coverImg(g, 120, 70)}</div>
      <div class="library-info">
        <h3>${g.title}</h3>
        <div class="playtime">${pt} ч. в игре</div>
        <button class="btn btn-primary btn-sm play-btn">Играть</button>
      </div>
    `;
    card.querySelector('.play-btn').onclick = (e) => {
      e.stopPropagation();
      state.playtimes[g.id] = (state.playtimes[g.id] || 0) + 1;
      saveAll();
      toast(`Запуск «${g.title}»… (+1 ч)`);
      renderLibrary();
    };
    card.onclick = () => openGameDetail(g.id);
    grid.appendChild(card);
  });
  save('gs_playtimes', state.playtimes);
}

/* ===== Profile ===== */
function renderProfile() {
  if (!state.user) {
    showPage('store');
    openAuth('login');
    return;
  }

  const { level, progress } = getLevel();
  const totalHours = Object.values(state.playtimes).reduce((a, b) => a + Number(b), 0);
  const avatarBg = state.user.avatarColor || AVATAR_COLORS[0];
  const initial = (state.user.name || state.user.email)[0].toUpperCase();

  $('#profile-content').innerHTML = `
    <div class="profile-sidebar">
      <div class="profile-banner"></div>
      <div class="profile-avatar-wrap">
        <div class="profile-avatar" id="profile-avatar" style="background:${avatarBg}">${initial}</div>
        <div class="profile-name">${state.user.name || 'Игрок'}</div>
        <div class="profile-email">${state.user.email}</div>
        <div class="profile-level">
          <span class="level-badge">Ур. ${level}</span>
          <span style="font-size:12px;color:var(--text-muted)">${Math.floor(progress)}/100 XP</span>
        </div>
        <div class="xp-bar"><div class="xp-fill" style="width:${progress}%"></div></div>
      </div>
      <div class="profile-stats">
        <div class="stat-item"><div class="num">${state.library.length}</div><div class="label">Игр</div></div>
        <div class="stat-item"><div class="num">${totalHours}</div><div class="label">Часов</div></div>
        <div class="stat-item"><div class="num">${state.wishlist.length}</div><div class="label">Желаемое</div></div>
        <div class="stat-item"><div class="num">${state.achievements.length}</div><div class="label">Наград</div></div>
      </div>
      <div class="profile-actions">
        <button class="btn btn-secondary btn-block btn-sm" id="prof-edit">Настройки</button>
      </div>
    </div>
    <div class="profile-main">
      <div class="profile-tabs">
        <button class="profile-tab ${state.profileTab === 'overview' ? 'active' : ''}" data-tab="overview">Обзор</button>
        <button class="profile-tab ${state.profileTab === 'achievements' ? 'active' : ''}" data-tab="achievements">Достижения</button>
        <button class="profile-tab ${state.profileTab === 'activity' ? 'active' : ''}" data-tab="activity">Активность</button>
        <button class="profile-tab ${state.profileTab === 'settings' ? 'active' : ''}" data-tab="settings">Настройки</button>
      </div>
      <div class="profile-panel ${state.profileTab === 'overview' ? 'active' : ''}" id="panel-overview">
        <h3 style="color:var(--text-bright);margin-bottom:12px;font-size:15px">Недавние игры</h3>
        <div class="library-grid" id="profile-recent"></div>
        ${state.library.length === 0 ? '<p style="color:var(--text-muted);font-size:13px">Пока нет игр в библиотеке</p>' : ''}
      </div>
      <div class="profile-panel ${state.profileTab === 'achievements' ? 'active' : ''}" id="panel-achievements">
        <div class="achievements-grid" id="ach-grid"></div>
      </div>
      <div class="profile-panel ${state.profileTab === 'activity' ? 'active' : ''}" id="panel-activity">
        <ul class="activity-list" id="activity-list"></ul>
        ${state.activity.length === 0 ? '<p style="color:var(--text-muted);font-size:13px">Пока нет активности</p>' : ''}
      </div>
      <div class="profile-panel ${state.profileTab === 'settings' ? 'active' : ''}" id="panel-settings">
        <form class="settings-form" id="settings-form">
          <div class="form-group">
            <label>Имя</label>
            <input type="text" id="set-name" value="${(state.user.name || '').replace(/"/g, '&quot;')}" />
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" id="set-email" value="${state.user.email || ''}" disabled />
          </div>
          <div class="form-group">
            <label>О себе</label>
            <textarea id="set-bio" placeholder="Расскажите о себе...">${(state.user.bio || '').replace(/</g, '&lt;')}</textarea>
          </div>
          <div class="form-group">
            <label>Цвет аватара</label>
            <div class="avatar-picker" id="avatar-picker">
              ${AVATAR_COLORS.map((c, i) =>
                `<div class="avatar-option ${state.user.avatarColor === c || (!state.user.avatarColor && i === 0) ? 'selected' : ''}" style="background:${c}" data-color="${c}"></div>`
              ).join('')}
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Сохранить</button>
        </form>
      </div>
    </div>
  `;

  const recent = state.library.slice(-6).reverse().map(id => getGame(id)).filter(Boolean);
  const recentEl = $('#profile-recent');
  if (recentEl) {
    recent.forEach(g => {
      const card = document.createElement('div');
      card.className = 'library-card';
      card.innerHTML = `
        <div class="library-cover">${coverImg(g, 120, 70)}</div>
        <div class="library-info">
          <h3>${g.title}</h3>
          <div class="playtime">${state.playtimes[g.id] || 0} ч.</div>
        </div>
      `;
      card.onclick = () => openGameDetail(g.id);
      recentEl.appendChild(card);
    });
  }

  const achGrid = $('#ach-grid');
  if (achGrid) {
    ACHIEVEMENTS.forEach(a => {
      const unlocked = state.achievements.includes(a.id);
      const el = document.createElement('div');
      el.className = `achievement ${unlocked ? 'unlocked' : ''}`;
      el.innerHTML = `
        <div class="achievement-icon">${a.icon}</div>
        <div class="achievement-info">
          <h4>${a.title}</h4>
          <p>${a.desc}</p>
        </div>
      `;
      achGrid.appendChild(el);
    });
  }

  const actList = $('#activity-list');
  if (actList) {
    state.activity.forEach(a => {
      const li = document.createElement('li');
      li.className = 'activity-item';
      li.innerHTML = `<span class="time">${a.time}</span><span>${a.text}</span>`;
      actList.appendChild(li);
    });
  }

  $$('.profile-tab').forEach(tab => {
    tab.onclick = () => {
      state.profileTab = tab.dataset.tab;
      renderProfile();
    };
  });

  $('#prof-edit')?.addEventListener('click', () => {
    state.profileTab = 'settings';
    renderProfile();
  });

  $$('.avatar-option').forEach(opt => {
    opt.onclick = () => {
      $$('.avatar-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      state.user.avatarColor = opt.dataset.color;
      $('#profile-avatar').style.background = opt.dataset.color;
      updateUserUI();
    };
  });

  $('#settings-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    state.user.name = $('#set-name').value.trim() || state.user.name;
    state.user.bio = $('#set-bio').value.trim();
    const selected = $('.avatar-option.selected');
    if (selected) state.user.avatarColor = selected.dataset.color;
    saveAll();
    updateUserUI();
    toast('Профиль сохранён');
    state.profileTab = 'overview';
    renderProfile();
  });
}

/* ===== Auth ===== */
function updateUserUI() {
  const nameEl = $('#header-username');
  const avatar = $('#header-avatar');
  if (state.user) {
    nameEl.textContent = state.user.name || state.user.email.split('@')[0];
    avatar.textContent = (state.user.name || state.user.email)[0].toUpperCase();
    if (state.user.avatarColor) avatar.style.background = state.user.avatarColor;
    $('#login-btn').classList.add('hidden');
    $('#register-btn').classList.add('hidden');
    $('#profile-btn').classList.remove('hidden');
    $('#logout-btn').classList.remove('hidden');
  } else {
    nameEl.textContent = 'Гость';
    avatar.textContent = 'G';
    avatar.style.background = '';
    $('#login-btn').classList.remove('hidden');
    $('#register-btn').classList.remove('hidden');
    $('#profile-btn').classList.add('hidden');
    $('#logout-btn').classList.add('hidden');
  }
}

function openAuth(mode = 'login') {
  state.authMode = mode;
  const title = $('#modal-title');
  const submit = $('#auth-submit');
  const switchText = $('#auth-switch-text');
  const switchBtn = $('#auth-switch-btn');
  const nameGroup = $('#auth-name-group');

  if (mode === 'login') {
    title.textContent = 'Вход';
    submit.textContent = 'Войти';
    switchText.textContent = 'Нет аккаунта?';
    switchBtn.textContent = 'Зарегистрироваться';
    nameGroup.classList.add('hidden');
  } else {
    title.textContent = 'Регистрация';
    submit.textContent = 'Создать аккаунт';
    switchText.textContent = 'Уже есть аккаунт?';
    switchBtn.textContent = 'Войти';
    nameGroup.classList.remove('hidden');
  }
  $('#auth-modal').classList.add('open');
}

function closeAuth() {
  $('#auth-modal').classList.remove('open');
  $('#auth-form').reset();
}

function handleAuth(e) {
  e.preventDefault();
  const email = $('#auth-email').value.trim();
  const name = $('#auth-name').value.trim();

  if (state.authMode === 'register') {
    if (!name) { toast('Введите имя'); return; }
    state.user = {
      email,
      name,
      avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
      bio: ''
    };
    addActivity('Регистрация в Grok Steam');
    toast(`Добро пожаловать, ${name}!`);
  } else {
    state.user = {
      email,
      name: email.split('@')[0],
      avatarColor: AVATAR_COLORS[0],
      bio: ''
    };
    toast(`С возвращением, ${state.user.name}!`);
  }
  checkAchievements();
  saveAll();
  updateUserUI();
  closeAuth();
}

function logout() {
  state.user = null;
  saveAll();
  updateUserUI();
  toast('Вы вышли из аккаунта');
  $('#user-dropdown').classList.remove('open');
  showPage('store');
}

/* ===== Navigation ===== */
function showPage(name) {
  $$('.page').forEach(p => p.classList.remove('active'));
  $(`#page-${name}`)?.classList.add('active');
  $$('.nav-link').forEach(l => l.classList.toggle('active', l.dataset.page === name));

  if (name === 'library') renderLibrary();
  if (name === 'store') renderStore();
  if (name === 'wishlist') renderWishlist();
  if (name === 'profile') renderProfile();
  if (name === 'community') {
    if (!state.achievements.includes('social')) {
      state.achievements.push('social');
      saveAll();
      toast('🏆 Достижение: Общительный');
    }
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ===== Init ===== */
function init() {
  setupHero();
  renderStore();
  updateBadges();
  updateUserUI();
  checkAchievements();

  $$('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      showPage(link.dataset.page);
    });
  });

  $('#logo-btn').addEventListener('click', e => { e.preventDefault(); showPage('store'); });
  $('#back-to-store').addEventListener('click', () => showPage('store'));
  $('#go-to-store')?.addEventListener('click', () => showPage('store'));
  $('#go-to-store-wl')?.addEventListener('click', () => showPage('store'));
  $('#wishlist-header-btn').addEventListener('click', () => showPage('wishlist'));

  $$('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $$('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentCategory = btn.dataset.cat;
      renderStore();
    });
  });

  $('#sort-select').addEventListener('change', e => {
    state.sortBy = e.target.value;
    renderStore();
  });

  let searchTimeout;
  $('#search-input').addEventListener('input', e => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      state.searchQuery = e.target.value;
      renderStore();
      showPage('store');
    }, 250);
  });

  $('#library-search')?.addEventListener('input', () => renderLibrary());
  $('#library-sort')?.addEventListener('change', () => renderLibrary());

  $('#cart-btn').addEventListener('click', openCart);
  $('#close-cart').addEventListener('click', closeCart);
  $('#overlay').addEventListener('click', () => { closeCart(); closeAuth(); });
  $('#checkout-btn').addEventListener('click', checkout);

  $('#user-btn').addEventListener('click', e => {
    e.stopPropagation();
    $('#user-dropdown').classList.toggle('open');
  });
  document.addEventListener('click', () => $('#user-dropdown').classList.remove('open'));

  $('#login-btn').addEventListener('click', e => { e.preventDefault(); openAuth('login'); });
  $('#register-btn').addEventListener('click', e => { e.preventDefault(); openAuth('register'); });
  $('#logout-btn').addEventListener('click', e => { e.preventDefault(); logout(); });
  $('#profile-btn').addEventListener('click', e => { e.preventDefault(); showPage('profile'); });

  $('#modal-close').addEventListener('click', closeAuth);
  $('#auth-form').addEventListener('submit', handleAuth);
  $('#auth-switch-btn').addEventListener('click', e => {
    e.preventDefault();
    openAuth(state.authMode === 'login' ? 'register' : 'login');
  });

  // Mobile burger
  const burger = $('#burger');
  const mobileNav = $('#mobile-nav');
  if (burger && mobileNav) {
    burger.addEventListener('click', () => mobileNav.classList.toggle('open'));
    mobileNav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', e => {
        e.preventDefault();
        const page = a.dataset.page;
        if (page === 'profile' && !state.user) { openAuth('login'); }
        else showPage(page);
        mobileNav.classList.remove('open');
      });
    });
  }

  // Footer links
  document.querySelectorAll('.footer a[data-page]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      showPage(a.dataset.page);
    });
  });
}

document.addEventListener('DOMContentLoaded', init);
