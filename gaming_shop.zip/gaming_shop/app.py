from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = 'gaming-peripherals-secret-key-2024-super-secure'

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Пожалуйста, войдите для доступа к этой странице.'
login_manager.login_message_category = 'warning'

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shop.db')

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Categories
    c.execute('''CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        icon TEXT
    )''')
    
    # Products
    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        old_price REAL,
        category_id INTEGER,
        image_url TEXT,
        stock INTEGER DEFAULT 50,
        brand TEXT,
        rating REAL DEFAULT 4.5,
        features TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id)
    )''')
    
    # Cart
    c.execute('''CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 1,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id),
        UNIQUE(user_id, product_id)
    )''')
    
    # Orders
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        total REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        address TEXT,
        phone TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')
    
    # Order items
    c.execute('''CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )''')
    
    # Reviews
    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')
    
    conn.commit()
    
    # Seed data if empty
    c.execute('SELECT COUNT(*) FROM categories')
    if c.fetchone()[0] == 0:
        categories = [
            ('Мыши', 'mice', '🖱️'),
            ('Клавиатуры', 'keyboards', '⌨️'),
            ('Наушники', 'headsets', '🎧'),
            ('Коврики', 'mousepads', '🖼️'),
            ('Геймпады', 'controllers', '🎮'),
            ('Мониторы', 'monitors', '🖥️'),
        ]
        c.executemany('INSERT INTO categories (name, slug, icon) VALUES (?, ?, ?)', categories)
        
        products = [
            # Mice
            ('Logitech G Pro X Superlight 2', 'Легчайшая беспроводная игровая мышь весом всего 60г. Сенсор HERO 2, 32K DPI, оптические переключатели.', 14990, 17990, 1, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400', 25, 'Logitech', 4.9, '60г, 32K DPI, 95 часов батареи, Lightspeed'),
            ('Razer Viper V3 Pro', 'Профессиональная киберспортивная мышь. Focus Pro 30K сенсор, 54г.', 13990, None, 1, 'https://images.unsplash.com/photo-1615662977969-6c2d7c0e2e5c?w=400', 30, 'Razer', 4.8, '54г, 30K DPI, 90 часов, HyperSpeed'),
            ('SteelSeries Aerox 5 Wireless', 'Ультралёгкая мышь с RGB и боковыми кнопками. 74г.', 9990, 12990, 1, 'https://images.unsplash.com/photo-1563297007-0686b7003af7?w=400', 40, 'SteelSeries', 4.6, '74г, 18K DPI, AquaGuard, RGB'),
            ('Zowie EC2-CW', 'Беспроводная версия легендарной EC2. Эргономичная форма.', 11990, None, 1, 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400', 15, 'Zowie', 4.7, 'Эргономика, 3200 DPI, беспроводная'),
            
            # Keyboards
            ('Razer BlackWidow V4 Pro', 'Механическая клавиатура с OLED дисплеем и Command Dial.', 24990, 29990, 2, 'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400', 20, 'Razer', 4.8, 'Razer Green, OLED, Command Dial, RGB'),
            ('Keychron Q1 Pro', 'Кастомная механическая клавиатура 75%. Беспроводная, Gasket Mount.', 18990, None, 2, 'https://images.unsplash.com/photo-1587829741301-dc430b73f898?w=400', 35, 'Keychron', 4.9, 'Gasket Mount, Hot-swap, Bluetooth/2.4G'),
            ('Corsair K70 RGB Pro', 'Алюминиевая рамка, переключатели Cherry MX, медиа-колёсико.', 16990, 19990, 2, 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=400', 28, 'Corsair', 4.7, 'Cherry MX Red, RGB, Aluminum'),
            ('Logitech G915 TKL', 'Низкопрофильная беспроводная механика. Lightspeed + Bluetooth.', 21990, None, 2, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400', 18, 'Logitech', 4.6, 'GL Tactile, TKL, 40 часов'),
            
            # Headsets
            ('HyperX Cloud III', 'Легендарный комфорт. 53мм драйверы, съёмный микрофон.', 8990, 10990, 3, 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400', 50, 'HyperX', 4.8, '53мм, DTS, Memory foam, USB/3.5mm'),
            ('SteelSeries Arctis Nova Pro Wireless', 'Премиум беспроводная гарнитура с активным шумоподавлением.', 34990, None, 3, 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', 12, 'SteelSeries', 4.9, 'ANC, Dual battery, 360° Spatial'),
            ('Razer BlackShark V2 Pro', 'Киберспортивная гарнитура с THX Spatial Audio.', 15990, 18990, 3, 'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=400', 22, 'Razer', 4.7, 'THX, 50мм, HyperClear mic'),
            ('Sony INZONE H9', 'Беспроводные с ANC и 360 Spatial Sound от Sony.', 27990, None, 3, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400', 15, 'Sony', 4.5, 'ANC, 360 Spatial, 32 часа'),
            
            # Mousepads
            ('SteelSeries QcK Heavy XXL', 'Толстый тканевый коврик 900x400x4мм.', 2990, 3490, 4, 'https://images.unsplash.com/photo-1616587894289-86480e533129?w=400', 100, 'SteelSeries', 4.8, '900x400, 4мм, ткань'),
            ('Artisan Zero Soft XL', 'Премиум японский коврик. Контроль и скорость.', 5990, None, 4, 'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=400', 40, 'Artisan', 4.9, 'Soft, XL, Япония'),
            ('Razer Firefly V2', 'RGB коврик с микротекстурированной поверхностью.', 4990, 5990, 4, 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400', 60, 'Razer', 4.5, 'RGB, Hard, Chroma'),
            
            # Controllers
            ('Sony DualSense Edge', 'Профессиональный геймпад с сменными стиками и кнопками.', 19990, None, 5, 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400', 25, 'Sony', 4.8, 'Сменные модули, Trigger stops, PC/PS5'),
            ('Xbox Elite Series 2', 'Премиум геймпад с настраиваемыми стиками и кнопками.', 17990, 19990, 5, 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=400', 30, 'Microsoft', 4.7, 'Сменные стики, Hair Triggers, 40 часов'),
            ('Razer Wolverine V2 Chroma', 'Проводной геймпад с RGB и дополнительными кнопками.', 9990, None, 5, 'https://images.unsplash.com/photo-1592840496694-26d035b52b48?w=400', 35, 'Razer', 4.6, 'RGB, Mecha-Tactile, PC/Xbox'),
            
            # Monitors
            ('ASUS ROG Swift PG27AQDM', '27" OLED 240Hz, 0.03ms, HDR10.', 89990, 99990, 6, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400', 8, 'ASUS', 4.9, 'OLED, 240Hz, 0.03ms, G-Sync'),
            ('LG UltraGear 27GP950', '27" 4K 144Hz Nano IPS, HDMI 2.1.', 54990, 64990, 6, 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=400', 12, 'LG', 4.7, '4K, 144Hz, HDMI 2.1, HDR600'),
            ('Samsung Odyssey G7 32"', '32" QHD 240Hz, 1000R, VA.', 39990, 44990, 6, 'https://images.unsplash.com/photo-1616763355548-1b606f371b53?w=400', 15, 'Samsung', 4.6, 'QHD, 240Hz, 1000R, HDR600'),
        ]
        
        c.executemany('''INSERT INTO products 
            (name, description, price, old_price, category_id, image_url, stock, brand, rating, features) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', products)
        
        # Admin user
        admin_hash = generate_password_hash('admin123')
        c.execute('INSERT INTO users (username, email, password_hash, is_admin) VALUES (?, ?, ?, ?)',
                  ('admin', 'admin@gamingshop.ru', admin_hash, 1))
        
        # Demo user
        user_hash = generate_password_hash('demo123')
        c.execute('INSERT INTO users (username, email, password_hash, is_admin) VALUES (?, ?, ?, ?)',
                  ('demo', 'demo@mail.ru', user_hash, 0))
        
        conn.commit()
    
    conn.close()

class User(UserMixin):
    def __init__(self, id, username, email, is_admin=False):
        self.id = id
        self.username = username
        self.email = email
        self.is_admin = is_admin

@login_manager.user_loader
def load_user(user_id):
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user:
        return User(user['id'], user['username'], user['email'], user['is_admin'])
    return None

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Доступ только для администратора', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ============== ROUTES ==============

@app.route('/')
def index():
    conn = get_db()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    products = conn.execute('''
        SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        ORDER BY p.rating DESC LIMIT 8
    ''').fetchall()
    conn.close()
    return render_template('index.html', products=products, categories=categories)

@app.route('/catalog')
def catalog():
    conn = get_db()
    category_slug = request.args.get('category')
    search = request.args.get('q', '').strip()
    sort = request.args.get('sort', 'rating')
    brand = request.args.get('brand')
    
    query = '''SELECT p.*, c.name as category_name, c.slug as category_slug 
               FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1'''
    params = []
    
    if category_slug:
        query += ' AND c.slug = ?'
        params.append(category_slug)
    
    if search:
        query += ' AND (p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%', f'%{search}%'])
    
    if brand:
        query += ' AND p.brand = ?'
        params.append(brand)
    
    if sort == 'price_asc':
        query += ' ORDER BY p.price ASC'
    elif sort == 'price_desc':
        query += ' ORDER BY p.price DESC'
    elif sort == 'name':
        query += ' ORDER BY p.name ASC'
    else:
        query += ' ORDER BY p.rating DESC'
    
    products = conn.execute(query, params).fetchall()
    categories = conn.execute('SELECT * FROM categories').fetchall()
    brands = conn.execute('SELECT DISTINCT brand FROM products ORDER BY brand').fetchall()
    conn.close()
    
    return render_template('catalog.html', products=products, categories=categories, 
                           brands=brands, current_category=category_slug, 
                           search=search, sort=sort, current_brand=brand)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    conn = get_db()
    product = conn.execute('''
        SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM products p JOIN categories c ON p.category_id = c.id 
        WHERE p.id = ?
    ''', (product_id,)).fetchone()
    
    if not product:
        flash('Товар не найден', 'danger')
        return redirect(url_for('catalog'))
    
    reviews = conn.execute('''
        SELECT r.*, u.username FROM reviews r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.product_id = ? ORDER BY r.created_at DESC
    ''', (product_id,)).fetchall()
    
    related = conn.execute('''
        SELECT * FROM products WHERE category_id = ? AND id != ? LIMIT 4
    ''', (product['category_id'], product_id)).fetchall()
    
    conn.close()
    return render_template('product.html', product=product, reviews=reviews, related=related)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        password2 = request.form.get('password2', '')
        
        if not username or not email or not password:
            flash('Заполните все поля', 'danger')
            return render_template('register.html')
        
        if password != password2:
            flash('Пароли не совпадают', 'danger')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('Пароль должен быть не менее 6 символов', 'danger')
            return render_template('register.html')
        
        conn = get_db()
        try:
            password_hash = generate_password_hash(password)
            conn.execute('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                        (username, email, password_hash))
            conn.commit()
            flash('Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Пользователь с таким именем или email уже существует', 'danger')
        finally:
            conn.close()
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? OR email = ?', 
                           (username, username)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            user_obj = User(user['id'], user['username'], user['email'], user['is_admin'])
            login_user(user_obj, remember=True)
            flash(f'Добро пожаловать, {user["username"]}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))

@app.route('/cart')
@login_required
def cart():
    conn = get_db()
    items = conn.execute('''
        SELECT c.id as cart_id, c.quantity, p.*, 
               (c.quantity * p.price) as subtotal
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ''', (current_user.id,)).fetchall()
    
    total = sum(item['subtotal'] for item in items)
    conn.close()
    return render_template('cart.html', items=items, total=total)

@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    if quantity < 1:
        quantity = 1
    
    conn = get_db()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        flash('Товар не найден', 'danger')
        conn.close()
        return redirect(url_for('catalog'))
    
    if product['stock'] < quantity:
        flash('Недостаточно товара на складе', 'warning')
        conn.close()
        return redirect(url_for('product_detail', product_id=product_id))
    
    existing = conn.execute('SELECT * FROM cart WHERE user_id = ? AND product_id = ?',
                           (current_user.id, product_id)).fetchone()
    
    if existing:
        new_qty = existing['quantity'] + quantity
        if new_qty > product['stock']:
            flash('Недостаточно товара на складе', 'warning')
        else:
            conn.execute('UPDATE cart SET quantity = ? WHERE id = ?', (new_qty, existing['id']))
            conn.commit()
            flash('Количество товара в корзине обновлено', 'success')
    else:
        conn.execute('INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)',
                    (current_user.id, product_id, quantity))
        conn.commit()
        flash('Товар добавлен в корзину', 'success')
    
    conn.close()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True})
    
    return redirect(request.referrer or url_for('catalog'))

@app.route('/cart/update/<int:cart_id>', methods=['POST'])
@login_required
def update_cart(cart_id):
    quantity = int(request.form.get('quantity', 1))
    conn = get_db()
    
    item = conn.execute('SELECT c.*, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.id = ? AND c.user_id = ?',
                       (cart_id, current_user.id)).fetchone()
    
    if not item:
        flash('Товар не найден в корзине', 'danger')
        conn.close()
        return redirect(url_for('cart'))
    
    if quantity <= 0:
        conn.execute('DELETE FROM cart WHERE id = ?', (cart_id,))
        flash('Товар удалён из корзины', 'info')
    elif quantity > item['stock']:
        flash('Недостаточно товара на складе', 'warning')
    else:
        conn.execute('UPDATE cart SET quantity = ? WHERE id = ?', (quantity, cart_id))
        flash('Корзина обновлена', 'success')
    
    conn.commit()
    conn.close()
    return redirect(url_for('cart'))

@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_id):
    conn = get_db()
    conn.execute('DELETE FROM cart WHERE id = ? AND user_id = ?', (cart_id, current_user.id))
    conn.commit()
    conn.close()
    flash('Товар удалён из корзины', 'info')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    conn = get_db()
    items = conn.execute('''
        SELECT c.quantity, p.*, (c.quantity * p.price) as subtotal
        FROM cart c JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ''', (current_user.id,)).fetchall()
    
    if not items:
        flash('Корзина пуста', 'warning')
        conn.close()
        return redirect(url_for('cart'))
    
    total = sum(item['subtotal'] for item in items)
    
    if request.method == 'POST':
        address = request.form.get('address', '').strip()
        phone = request.form.get('phone', '').strip()
        
        if not address or not phone:
            flash('Заполните адрес и телефон', 'danger')
            conn.close()
            return render_template('checkout.html', items=items, total=total)
        
        # Check stock
        for item in items:
            if item['quantity'] > item['stock']:
                flash(f'Недостаточно товара: {item["name"]}', 'danger')
                conn.close()
                return redirect(url_for('cart'))
        
        # Create order
        cursor = conn.execute(
            'INSERT INTO orders (user_id, total, address, phone, status) VALUES (?, ?, ?, ?, ?)',
            (current_user.id, total, address, phone, 'processing')
        )
        order_id = cursor.lastrowid
        
        for item in items:
            conn.execute(
                'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
                (order_id, item['id'], item['quantity'], item['price'])
            )
            # Decrease stock
            conn.execute('UPDATE products SET stock = stock - ? WHERE id = ?',
                        (item['quantity'], item['id']))
        
        # Clear cart
        conn.execute('DELETE FROM cart WHERE user_id = ?', (current_user.id,))
        conn.commit()
        conn.close()
        
        flash(f'Заказ №{order_id} успешно оформлен! Сумма: {total:,.0f} ₽', 'success')
        return redirect(url_for('orders'))
    
    conn.close()
    return render_template('checkout.html', items=items, total=total)

@app.route('/orders')
@login_required
def orders():
    conn = get_db()
    user_orders = conn.execute('''
        SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC
    ''', (current_user.id,)).fetchall()
    
    orders_with_items = []
    for order in user_orders:
        items = conn.execute('''
            SELECT oi.*, p.name, p.image_url 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ''', (order['id'],)).fetchall()
        orders_with_items.append({'order': order, 'items': items})
    
    conn.close()
    return render_template('orders.html', orders=orders_with_items)

@app.route('/review/<int:product_id>', methods=['POST'])
@login_required
def add_review(product_id):
    rating = int(request.form.get('rating', 5))
    comment = request.form.get('comment', '').strip()
    
    if rating < 1 or rating > 5:
        flash('Оценка от 1 до 5', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))
    
    conn = get_db()
    
    # Check if already reviewed
    existing = conn.execute('SELECT id FROM reviews WHERE product_id = ? AND user_id = ?',
                           (product_id, current_user.id)).fetchone()
    if existing:
        flash('Вы уже оставляли отзыв на этот товар', 'warning')
        conn.close()
        return redirect(url_for('product_detail', product_id=product_id))
    
    conn.execute('INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)',
                (product_id, current_user.id, rating, comment))
    
    # Update product rating
    avg = conn.execute('SELECT AVG(rating) FROM reviews WHERE product_id = ?', (product_id,)).fetchone()[0]
    conn.execute('UPDATE products SET rating = ? WHERE id = ?', (round(avg, 1), product_id))
    
    conn.commit()
    conn.close()
    flash('Отзыв добавлен!', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/profile')
@login_required
def profile():
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (current_user.id,)).fetchone()
    order_count = conn.execute('SELECT COUNT(*) FROM orders WHERE user_id = ?', (current_user.id,)).fetchone()[0]
    cart_count = conn.execute('SELECT COUNT(*) FROM cart WHERE user_id = ?', (current_user.id,)).fetchone()[0]
    conn.close()
    return render_template('profile.html', user=user, order_count=order_count, cart_count=cart_count)

@app.route('/admin')
@login_required
@admin_required
def admin():
    conn = get_db()
    products = conn.execute('SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY p.id').fetchall()
    orders = conn.execute('''
        SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id 
        ORDER BY o.created_at DESC LIMIT 20
    ''').fetchall()
    stats = {
        'products': conn.execute('SELECT COUNT(*) FROM products').fetchone()[0],
        'users': conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],
        'orders': conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0],
        'revenue': conn.execute('SELECT COALESCE(SUM(total), 0) FROM orders').fetchone()[0],
    }
    conn.close()
    return render_template('admin.html', products=products, orders=orders, stats=stats)

@app.route('/admin/order/<int:order_id>/status', methods=['POST'])
@login_required
@admin_required
def update_order_status(order_id):
    status = request.form.get('status')
    valid = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']
    if status in valid:
        conn = get_db()
        conn.execute('UPDATE orders SET status = ? WHERE id = ?', (status, order_id))
        conn.commit()
        conn.close()
        flash('Статус заказа обновлён', 'success')
    return redirect(url_for('admin'))

@app.context_processor
def inject_cart_count():
    if current_user.is_authenticated:
        conn = get_db()
        count = conn.execute('SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?',
                            (current_user.id,)).fetchone()[0]
        conn.close()
        return {'cart_count': count}
    return {'cart_count': 0}

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
