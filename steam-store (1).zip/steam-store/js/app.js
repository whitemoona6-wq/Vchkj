/* ===== State ===== */
const state = {
  cart: JSON.parse(localStorage.getItem('gs_cart') || '[]'),
  library: JSON.parse(localStorage.getItem('gs_library') || '[]'),
  user: JSON.parse(localStorage.getItem('gs_user') || 'null'),
  currentCategory: 'all',
  searchQuery: '',
  authMode: 'login' // 'login' | 'register'
};

/* ===== Helpers ===== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function formatPrice(n) {
  if (n === 0) return 'Бесплатно';
  return n.toLocaleString('ru-RU') + ' ₽';
}

function saveCart() {
  localStorage.setItem('gs_cart', JSON.stringify(state.cart));
  updateCartUI();
}

function saveLibrary() {
  localStorage.setItem('gs_library', JSON.stringify(state.library));
}

function saveUser() {
  localStorage.setItem('gs_user', JSON.stringify(state.user));
  updateUserUI();
}

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2800);
}

function getGame(id) {
  return GAMES.find(g => g.id === id);
}

/* ===== Render Game Card ===== */
function createGameCard(game) {
  const card = document.createElement('div');
  card.className = 'game-card';
  card.dataset.id = game.id;

  const priceHtml = game.price === 0
    ? `<span class="price-free">Бесплатно</span>`
    : `
      ${game.discount ? `<span class="price-discount">-${game.discount}%</span>` : ''}
      ${game.oldPrice ? `<span class="price-old">${formatPrice(game.oldPrice)}</span>` : ''}
      <span class="price-current">${formatPrice(game.price)}</span>
    `;

  card.innerHTML = `
    <div class="game-cover" style="background: ${game.cover}"></div>
    <div class="game-info">
      <div class="game-title">${game.title}</div>
      <div class="game-tags">
        ${game.tags.slice(0, 2).map(t => `<span class="game-tag">${t}</span>`).join('')}
      </div>
      <div class="game-price-row">${priceHtml}</div>
    </div>
  `;

  card.addEventListener('click', () => openGameDetail(game.id));
  return card;
}

/* ===== Store ===== */
function renderStore() {
  const filtered = GAMES.filter(g => {
    const catOk = state.currentCategory === 'all' || g.category.includes(state.currentCategory);
    const q = state.searchQuery.toLowerCase();
    const searchOk = !q || g.title.toLowerCase().includes(q) || g.tags.some(t => t.toLowerCase().includes(q));
    return catOk && searchOk;
  });

  // Offers (games with discount)
  const offers = filtered.filter(g => g.discount > 0).slice(0, 8);
  const offersRow = $('#offers-row');
  offersRow.innerHTML = '';
  if (offers.length === 0) {
    offersRow.innerHTML = '<p style="color:var(--text-muted);padding:20px 0">Нет предложений по выбранным фильтрам</p>';
  } else {
    offers.forEach(g => offersRow.appendChild(createGameCard(g)));
  }

  // All / Popular grid
  const grid = $('#games-grid');
  grid.innerHTML = '';
  if (filtered.length === 0) {
    grid.innerHTML = '<p style="color:var(--text-muted);grid-column:1/-1;padding:40px 0;text-align:center">Игры не найдены</p>';
  } else {
    filtered.forEach(g => grid.appendChild(createGameCard(g)));
  }
}

/* ===== Hero ===== */
function setupHero() {
  const featured = GAMES.find(g => g.featured) || GAMES[0];
  $('#hero-title').textContent = featured.title;
  $('#hero-desc').textContent = featured.description.slice(0, 160) + '…';
  $('#hero-price').textContent = formatPrice(featured.price);
  if (featured.discount) {
    $('#hero-discount').textContent = `-${featured.discount}%`;
    $('#hero-discount').style.display = '';
    $('#hero-old-price').textContent = formatPrice(featured.oldPrice);
    $('#hero-old-price').style.display = '';
  } else {
    $('#hero-discount').style.display = 'none';
    $('#hero-old-price').style.display = 'none';
  }

  $('#hero-buy').onclick = () => {
    addToCart(featured.id);
  };
  $('#hero-wishlist').onclick = () => toast('Добавлено в список желаемого (демо)');
}

/* ===== Game Detail ===== */
function openGameDetail(id) {
  const game = getGame(id);
  if (!game) return;

  const owned = state.library.includes(id);
  const inCart = state.cart.includes(id);

  const priceHtml = game.price === 0
    ? `<span class="price-current" style="font-size:20px;color:var(--green)">Бесплатно</span>`
    : `
      ${game.discount ? `<span class="price-discount" style="font-size:14px">-${game.discount}%</span>` : ''}
      ${game.oldPrice ? `<span class="price-old">${formatPrice(game.oldPrice)}</span>` : ''}
      <span class="price-current" style="font-size:20px">${formatPrice(game.price)}</span>
    `;

  let actionBtn;
  if (owned) {
    actionBtn = `<button class="btn btn-primary btn-block" disabled>Уже в библиотеке</button>`;
  } else if (inCart) {
    actionBtn = `<button class="btn btn-secondary btn-block" id="detail-in-cart">Уже в корзине</button>`;
  } else {
    actionBtn = `<button class="btn btn-primary btn-block" id="detail-buy">${game.price === 0 ? 'Получить' : 'В корзину'}</button>`;
  }

  $('#game-detail').innerHTML = `
    <div class="game-detail-header">
      <div class="game-detail-media" style="background: ${game.cover}"></div>
      <div class="game-detail-sidebar">
        <div class="cover-mini" style="background: ${game.cover}"></div>
        <h1>${game.title}</h1>
        <div class="tags">
          ${game.tags.map(t => `<span class="tag">${t}</span>`).join('')}
        </div>
        <div class="detail-price-block">
          <div class="detail-price-row">${priceHtml}</div>
          <div class="detail-actions">
            ${actionBtn}
            <button class="btn btn-secondary btn-block" id="detail-wishlist">В список желаемого</button>
          </div>
        </div>
        <div class="detail-meta">
          <div><span>Дата выхода</span><span>${game.release}</span></div>
          <div><span>Разработчик</span><span>${game.developer}</span></div>
          <div><span>Издатель</span><span>${game.publisher}</span></div>
          <div><span>Оценка</span><span>★ ${game.rating}</span></div>
        </div>
      </div>
    </div>
    <div class="game-description">
      <h2>Об этой игре</h2>
      <p>${game.description}</p>
    </div>
  `;

  const buyBtn = $('#detail-buy');
  if (buyBtn) {
    buyBtn.onclick = () => {
      addToCart(id);
      openGameDetail(id); // refresh
    };
  }

  $('#detail-wishlist')?.addEventListener('click', () => toast('Добавлено в список желаемого (демо)'));

  showPage('game');
}

/* ===== Cart ===== */
function addToCart(id) {
  if (state.library.includes(id)) {
    toast('Игра уже в вашей библиотеке');
    return;
  }
  if (state.cart.includes(id)) {
    toast('Игра уже в корзине');
    return;
  }
  state.cart.push(id);
  saveCart();
  toast('Добавлено в корзину');
}

function removeFromCart(id) {
  state.cart = state.cart.filter(x => x !== id);
  saveCart();
  renderCartItems();
}

function updateCartUI() {
  const count = state.cart.length;
  const badge = $('#cart-count');
  badge.textContent = count;
  badge.dataset.count = count;
  badge.style.display = count > 0 ? 'flex' : 'none';
}

function renderCartItems() {
  const container = $('#cart-items');
  if (state.cart.length === 0) {
    container.innerHTML = '<div class="cart-empty">Корзина пуста</div>';
    $('#cart-total').textContent = '0 ₽';
    return;
  }

  let total = 0;
  container.innerHTML = state.cart.map(id => {
    const g = getGame(id);
    if (!g) return '';
    total += g.price;
    return `
      <div class="cart-item">
        <div class="cart-item-cover" style="background: ${g.cover}"></div>
        <div class="cart-item-info">
          <h4>${g.title}</h4>
          <div class="price">${formatPrice(g.price)}</div>
        </div>
        <button class="cart-item-remove" data-id="${g.id}" title="Удалить">×</button>
      </div>
    `;
  }).join('');

  $('#cart-total').textContent = formatPrice(total);

  $$('.cart-item-remove', container).forEach(btn => {
    btn.onclick = () => removeFromCart(+btn.dataset.id);
  });
}

function openCart() {
  renderCartItems();
  $('#cart-sidebar').classList.add('open');
  $('#overlay').classList.add('open');
}

function closeCart() {
  $('#cart-sidebar').classList.remove('open');
  $('#overlay').classList.remove('open');
}

function checkout() {
  if (state.cart.length === 0) {
    toast('Корзина пуста');
    return;
  }
  if (!state.user) {
    toast('Войдите, чтобы оформить покупку');
    openAuth('login');
    return;
  }

  // Add to library
  state.cart.forEach(id => {
    if (!state.library.includes(id)) state.library.push(id);
  });
  state.cart = [];
  saveCart();
  saveLibrary();
  closeCart();
  toast('Покупка успешно оформлена! Игры добавлены в библиотеку.');
  renderLibrary();
}

/* ===== Library ===== */
function renderLibrary() {
  const grid = $('#library-grid');
  const empty = $('#library-empty');

  if (state.library.length === 0) {
    grid.innerHTML = '';
    grid.appendChild(empty);
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';

  const q = ($('#library-search')?.value || '').toLowerCase();
  const sort = $('#library-sort')?.value || 'name';

  let games = state.library.map(id => getGame(id)).filter(Boolean);
  if (q) games = games.filter(g => g.title.toLowerCase().includes(q));

  if (sort === 'name') games.sort((a, b) => a.title.localeCompare(b.title, 'ru'));
  // recent / playtime — mock order

  grid.innerHTML = '';
  games.forEach(g => {
    const playtime = Math.floor(Math.random() * 120) + 1; // mock
    const card = document.createElement('div');
    card.className = 'library-card';
    card.innerHTML = `
      <div class="library-cover" style="background: ${g.cover}"></div>
      <div class="library-info">
        <h3>${g.title}</h3>
        <div class="playtime">${playtime} ч. в игре</div>
        <button class="btn btn-primary btn-sm play-btn">Играть</button>
      </div>
    `;
    card.querySelector('.play-btn').onclick = (e) => {
      e.stopPropagation();
      toast(`Запуск «${g.title}»… (демо)`);
    };
    card.onclick = () => openGameDetail(g.id);
    grid.appendChild(card);
  });
}

/* ===== Auth ===== */
function updateUserUI() {
  const nameEl = $('.username');
  const avatar = $('.avatar');
  const loginBtn = $('#login-btn');
  const registerBtn = $('#register-btn');
  const profileBtn = $('#profile-btn');
  const logoutBtn = $('#logout-btn');

  if (state.user) {
    nameEl.textContent = state.user.name || state.user.email.split('@')[0];
    avatar.textContent = (state.user.name || state.user.email)[0].toUpperCase();
    loginBtn.classList.add('hidden');
    registerBtn.classList.add('hidden');
    profileBtn.classList.remove('hidden');
    logoutBtn.classList.remove('hidden');
  } else {
    nameEl.textContent = 'Гость';
    avatar.textContent = 'G';
    loginBtn.classList.remove('hidden');
    registerBtn.classList.remove('hidden');
    profileBtn.classList.add('hidden');
    logoutBtn.classList.add('hidden');
  }
}

function openAuth(mode = 'login') {
  state.authMode = mode;
  const modal = $('#auth-modal');
  const title = $('#modal-title');
  const submit = $('#auth-submit');
  const switchText = $('#auth-switch-text');
  const switchBtn = $('#auth-switch-btn');
  const nameGroup = $('#auth-name-group');

  if (mode === 'login') {
    title.textContent = 'Вход';
    submit.textContent = 'Войти';
    switchText.textContent = 'Нет аккаунта?';
    switchBtn.textContent = 'Зарегистрироваться';
    nameGroup.classList.add('hidden');
  } else {
    title.textContent = 'Регистрация';
    submit.textContent = 'Создать аккаунт';
    switchText.textContent = 'Уже есть аккаунт?';
    switchBtn.textContent = 'Войти';
    nameGroup.classList.remove('hidden');
  }

  modal.classList.add('open');
}

function closeAuth() {
  $('#auth-modal').classList.remove('open');
  $('#auth-form').reset();
}

function handleAuth(e) {
  e.preventDefault();
  const email = $('#auth-email').value.trim();
  const password = $('#auth-password').value;
  const name = $('#auth-name').value.trim();

  if (state.authMode === 'register') {
    if (!name) {
      toast('Введите имя');
      return;
    }
    state.user = { email, name };
    toast(`Добро пожаловать, ${name}!`);
  } else {
    // Demo login — accept any
    state.user = { email, name: email.split('@')[0] };
    toast(`С возвращением, ${state.user.name}!`);
  }

  saveUser();
  closeAuth();
}

function logout() {
  state.user = null;
  saveUser();
  toast('Вы вышли из аккаунта');
  $('#user-dropdown').classList.remove('open');
}

/* ===== Navigation ===== */
function showPage(name) {
  $$('.page').forEach(p => p.classList.remove('active'));
  $(`#page-${name}`)?.classList.add('active');

  $$('.nav-link').forEach(l => {
    l.classList.toggle('active', l.dataset.page === name);
  });

  if (name === 'library') renderLibrary();
  if (name === 'store') renderStore();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ===== Init ===== */
function init() {
  setupHero();
  renderStore();
  updateCartUI();
  updateUserUI();

  // Nav
  $$('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      showPage(link.dataset.page);
    });
  });

  $('#logo-btn').addEventListener('click', e => {
    e.preventDefault();
    showPage('store');
  });

  $('#back-to-store').addEventListener('click', () => showPage('store'));
  $('#go-to-store').addEventListener('click', () => showPage('store'));

  // Categories
  $$('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $$('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentCategory = btn.dataset.cat;
      renderStore();
    });
  });

  // Search
  let searchTimeout;
  $('#search-input').addEventListener('input', e => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      state.searchQuery = e.target.value;
      renderStore();
      showPage('store');
    }, 250);
  });

  // Library search / sort
  $('#library-search')?.addEventListener('input', () => renderLibrary());
  $('#library-sort')?.addEventListener('change', () => renderLibrary());

  // Cart
  $('#cart-btn').addEventListener('click', openCart);
  $('#close-cart').addEventListener('click', closeCart);
  $('#overlay').addEventListener('click', () => {
    closeCart();
    closeAuth();
  });
  $('#checkout-btn').addEventListener('click', checkout);

  // User menu
  $('#user-btn').addEventListener('click', e => {
    e.stopPropagation();
    $('#user-dropdown').classList.toggle('open');
  });
  document.addEventListener('click', () => {
    $('#user-dropdown').classList.remove('open');
  });

  $('#login-btn').addEventListener('click', e => {
    e.preventDefault();
    openAuth('login');
  });
  $('#register-btn').addEventListener('click', e => {
    e.preventDefault();
    openAuth('register');
  });
  $('#logout-btn').addEventListener('click', e => {
    e.preventDefault();
    logout();
  });
  $('#profile-btn').addEventListener('click', e => {
    e.preventDefault();
    toast(`Профиль: ${state.user?.name || state.user?.email}`);
  });

  // Auth modal
  $('#modal-close').addEventListener('click', closeAuth);
  $('#auth-form').addEventListener('submit', handleAuth);
  $('#auth-switch-btn').addEventListener('click', e => {
    e.preventDefault();
    openAuth(state.authMode === 'login' ? 'register' : 'login');
  });
}

document.addEventListener('DOMContentLoaded', init);
