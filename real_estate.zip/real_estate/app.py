from flask import Flask, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'super-secret-key-change-me-in-production'

DATABASE = 'real_estate.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                balance REAL DEFAULT 5000000.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS properties (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                location TEXT NOT NULL,
                rooms INTEGER DEFAULT 1,
                area REAL DEFAULT 50.0,
                image_url TEXT DEFAULT 'https://via.placeholder.com/600x400?text=Недвижимость',
                status TEXT DEFAULT 'available',
                owner_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (owner_id) REFERENCES users (id)
            );

            CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                property_id INTEGER NOT NULL,
                price REAL NOT NULL,
                purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (property_id) REFERENCES properties (id)
            );
        ''')
        db.commit()

        # Добавляем тестовые объекты, если таблица пустая
        cur = db.execute('SELECT COUNT(*) as cnt FROM properties')
        if cur.fetchone()['cnt'] == 0:
            sample_properties = [
                ('Квартира в центре Москвы', 'Просторная 3-комнатная квартира с ремонтом, вид на Кремль', 18500000, 'Москва, Тверская 12', 3, 95.5, 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=600'),
                ('Дом в Подмосковье', 'Уютный коттедж с участком 10 соток, баня, гараж', 12500000, 'Московская обл., Одинцово', 5, 180, 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600'),
                ('Студия у метро', 'Современная студия, полностью меблирована', 6800000, 'Москва, м. Сокольники', 1, 32, 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600'),
                ('Пентхаус с террасой', 'Роскошный пентхаус 4 комнаты + терраса 40 м²', 45000000, 'Москва, Пресненская наб.', 4, 210, 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600'),
                ('Квартира в новостройке', '2-комнатная в ЖК «Сердце столицы», сдача 2025', 11200000, 'Москва, Хорошёвское ш.', 2, 68, 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600'),
                ('Дача у озера', 'Деревянный дом, участок 15 соток, свой берег', 4200000, 'Тверская обл., озеро Селигер', 3, 95, 'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=600'),
            ]
            db.executemany(
                'INSERT INTO properties (title, description, price, location, rooms, area, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
                sample_properties
            )
            db.commit()

# ========== Аутентификация ==========

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password']
        confirm = request.form['confirm']

        if not username or not email or not password:
            flash('Заполните все поля', 'error')
            return redirect(url_for('register'))
        if password != confirm:
            flash('Пароли не совпадают', 'error')
            return redirect(url_for('register'))
        if len(password) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
            return redirect(url_for('register'))

        db = get_db()
        try:
            db.execute(
                'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                (username, email, generate_password_hash(password))
            )
            db.commit()
            flash('Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Пользователь с таким именем или email уже существует', 'error')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()

        if user and check_password_hash(user['password_hash'], password):
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash(f'Добро пожаловать, {user["username"]}!', 'success')
            return redirect(url_for('index'))
        flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из аккаунта', 'success')
    return redirect(url_for('index'))

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Сначала войдите в аккаунт', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ========== Основные страницы ==========

@app.route('/')
def index():
    db = get_db()
    properties = db.execute(
        'SELECT * FROM properties WHERE status = "available" ORDER BY created_at DESC LIMIT 6'
    ).fetchall()
    return render_template('index.html', properties=properties)

@app.route('/properties')
def properties():
    db = get_db()
    status = request.args.get('status', 'available')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    rooms = request.args.get('rooms', type=int)
    location = request.args.get('location', '').strip()

    query = 'SELECT * FROM properties WHERE 1=1'
    params = []

    if status:
        query += ' AND status = ?'
        params.append(status)
    if min_price is not None:
        query += ' AND price >= ?'
        params.append(min_price)
    if max_price is not None:
        query += ' AND price <= ?'
        params.append(max_price)
    if rooms is not None:
        query += ' AND rooms = ?'
        params.append(rooms)
    if location:
        query += ' AND location LIKE ?'
        params.append(f'%{location}%')

    query += ' ORDER BY created_at DESC'
    properties = db.execute(query, params).fetchall()
    return render_template('properties.html', properties=properties, filters=request.args)

@app.route('/property/<int:prop_id>')
def property_detail(prop_id):
    db = get_db()
    prop = db.execute('SELECT * FROM properties WHERE id = ?', (prop_id,)).fetchone()
    if not prop:
        flash('Объект не найден', 'error')
        return redirect(url_for('properties'))
    return render_template('property_detail.html', prop=prop)

@app.route('/buy/<int:prop_id>', methods=['POST'])
@login_required
def buy_property(prop_id):
    db = get_db()
    prop = db.execute('SELECT * FROM properties WHERE id = ?', (prop_id,)).fetchone()
    user = db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()

    if not prop:
        flash('Объект не найден', 'error')
        return redirect(url_for('properties'))
    if prop['status'] != 'available':
        flash('Этот объект уже продан', 'error')
        return redirect(url_for('property_detail', prop_id=prop_id))
    if user['balance'] < prop['price']:
        flash(f'Недостаточно средств. Нужно {prop["price"]:,.0f} ₽, у вас {user["balance"]:,.0f} ₽', 'error')
        return redirect(url_for('property_detail', prop_id=prop_id))

    # Покупка
    new_balance = user['balance'] - prop['price']
    db.execute('UPDATE users SET balance = ? WHERE id = ?', (new_balance, user['id']))
    db.execute('UPDATE properties SET status = "sold", owner_id = ? WHERE id = ?', (user['id'], prop_id))
    db.execute(
        'INSERT INTO purchases (user_id, property_id, price) VALUES (?, ?, ?)',
        (user['id'], prop_id, prop['price'])
    )
    db.commit()

    flash(f'Поздравляем! Вы купили «{prop["title"]}» за {prop["price"]:,.0f} ₽', 'success')
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    my_properties = db.execute(
        'SELECT * FROM properties WHERE owner_id = ? ORDER BY created_at DESC',
        (session['user_id'],)
    ).fetchall()
    purchases = db.execute('''
        SELECT p.title, p.location, pu.price, pu.purchase_date
        FROM purchases pu
        JOIN properties p ON pu.property_id = p.id
        WHERE pu.user_id = ?
        ORDER BY pu.purchase_date DESC
    ''', (session['user_id'],)).fetchall()
    return render_template('dashboard.html', user=user, my_properties=my_properties, purchases=purchases)

@app.route('/add_property', methods=['GET', 'POST'])
@login_required
def add_property():
    if request.method == 'POST':
        title = request.form['title'].strip()
        description = request.form['description'].strip()
        price = float(request.form['price'])
        location = request.form['location'].strip()
        rooms = int(request.form['rooms'])
        area = float(request.form['area'])
        image_url = request.form.get('image_url', '').strip() or 'https://via.placeholder.com/600x400?text=Недвижимость'

        if not title or price <= 0:
            flash('Заполните обязательные поля корректно', 'error')
            return redirect(url_for('add_property'))

        db = get_db()
        db.execute('''
            INSERT INTO properties (title, description, price, location, rooms, area, image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (title, description, price, location, rooms, area, image_url))
        db.commit()
        flash('Объект успешно добавлен!', 'success')
        return redirect(url_for('properties'))
    return render_template('add_property.html')

@app.route('/topup', methods=['POST'])
@login_required
def topup():
    amount = float(request.form.get('amount', 0))
    if amount <= 0:
        flash('Сумма должна быть положительной', 'error')
        return redirect(url_for('dashboard'))
    db = get_db()
    db.execute('UPDATE users SET balance = balance + ? WHERE id = ?', (amount, session['user_id']))
    db.commit()
    flash(f'Баланс пополнен на {amount:,.0f} ₽', 'success')
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    else:
        # На всякий случай проверяем таблицы
        init_db()
    app.run(debug=True, port=5000)
